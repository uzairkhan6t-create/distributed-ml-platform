"""Worker agent — run one of these per machine (or several per machine for a demo).

    python worker/agent.py --name Worker-01
    python worker/agent.py --name Worker-02 --server http://192.168.1.10:8000

The agent registers itself, heartbeats in the background, then loops: pull a task,
download its shard, compute a gradient, post it back. It holds no database and no
shared filesystem — everything moves over HTTP, which is what makes the cluster
genuinely distributed.
"""

from __future__ import annotations

import argparse
import base64
import io
import os
import platform
import random
import signal
import socket
import sys
import threading
import time

import numpy as np
import requests

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend.app.ml.model import local_update  # noqa: E402

DEFAULT_SERVER = os.getenv("DMLP_SERVER", "http://127.0.0.1:8000")
DEFAULT_TOKEN = os.getenv("DMLP_CLUSTER_TOKEN", "dev-cluster-token")

stop_flag = threading.Event()


def encode(vec: np.ndarray) -> str:
    return base64.b64encode(np.asarray(vec, dtype=np.float32).tobytes()).decode("ascii")


def decode(blob: str) -> np.ndarray:
    return np.frombuffer(base64.b64decode(blob), dtype=np.float32).astype(np.float64)


class Agent:
    def __init__(self, name: str, server: str, token: str, device: str, poll: float):
        self.name = name
        self.server = server.rstrip("/")
        self.api = f"{self.server}/api/v1"
        self.poll = poll
        self.device = device
        self.node_id: int | None = None
        self.shard_cache: dict[tuple, tuple[np.ndarray, np.ndarray]] = {}
        self.session = requests.Session()
        self.session.headers.update({"X-Cluster-Token": token})
        self.busy = False
        self.tasks_done = 0

    # --- lifecycle --------------------------------------------------------
    def register(self) -> None:
        payload = {
            "name": self.name,
            "hostname": socket.gethostname(),
            "device": self.device,
            "cpu_cores": os.cpu_count() or 1,
            "memory_gb": round(_total_memory_gb(), 1),
            "capabilities": {
                "python": platform.python_version(),
                "platform": platform.system(),
                "numpy": np.__version__,
            },
        }
        while not stop_flag.is_set():
            try:
                r = self.session.post(f"{self.api}/nodes/register", json=payload, timeout=15)
                r.raise_for_status()
                self.node_id = r.json()["id"]
                print(f"[{self.name}] joined the cluster as node {self.node_id}")
                return
            except Exception as exc:
                print(f"[{self.name}] cannot reach {self.server} ({exc}). Retrying in 5s.")
                stop_flag.wait(5)

    def heartbeat_loop(self) -> None:
        while not stop_flag.is_set():
            if self.node_id:
                try:
                    self.session.post(
                        f"{self.api}/nodes/{self.node_id}/heartbeat",
                        json={
                            "cpu_percent": self._cpu_percent(),
                            "gpu_percent": self._gpu_percent(),
                            "memory_percent": self._memory_percent(),
                        },
                        timeout=10,
                    )
                except Exception:
                    pass
            stop_flag.wait(8)

    # --- telemetry --------------------------------------------------------
    def _cpu_percent(self) -> float:
        try:
            load = os.getloadavg()[0] / (os.cpu_count() or 1) * 100
            return float(min(100.0, max(2.0, load)))
        except (OSError, AttributeError):
            return 70.0 if self.busy else 12.0

    def _gpu_percent(self) -> float:
        # Real GPU telemetry would come from nvidia-smi / pynvml. On a CPU-only box
        # we report how hard the agent itself is working.
        base = 78.0 if self.busy else 6.0
        return round(max(0.0, min(100.0, base + random.uniform(-6, 8))), 1)

    def _memory_percent(self) -> float:
        try:
            import resource
            used_gb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / (1024 * 1024)
            return round(min(99.0, 20 + used_gb / max(_total_memory_gb(), 1) * 100), 1)
        except Exception:
            return 45.0

    # --- work loop --------------------------------------------------------
    def fetch_shard(self, dataset_id: int, world_size: int, shard_index: int):
        key = (dataset_id, world_size, shard_index)
        if key in self.shard_cache:
            return self.shard_cache[key]

        url = f"{self.api}/datasets/{dataset_id}/shard/{world_size}/{shard_index}"
        r = self.session.get(url, timeout=120)
        r.raise_for_status()
        data = np.load(io.BytesIO(r.content))
        X = data["X"].astype(np.float64)
        y = data["y"].astype(np.int64)
        self.shard_cache[key] = (X, y)
        print(f"[{self.name}] downloaded shard {shard_index}/{world_size} "
              f"({len(y):,} rows, {len(r.content) / 1024:.0f} KB)")
        return X, y

    def run_task(self, task: dict) -> None:
        self.busy = True
        started = time.perf_counter()
        try:
            X, y = self.fetch_shard(task["dataset_id"], task["world_size"], task["shard_index"])
            grad, loss, acc, seen = local_update(
                flat_weights=decode(task["weights"]),
                layer_sizes=task["layer_sizes"],
                X=X,
                y=y,
                batch_size=task["batch_size"],
                local_steps=task["local_steps"],
                l2=task["l2"],
                seed=task["epoch"] * 1000 + task["shard_index"],
            )
            duration = (time.perf_counter() - started) * 1000
            self.session.post(
                f"{self.api}/tasks/{task['task_id']}/result",
                json={
                    "gradients": encode(grad),
                    "loss": float(loss),
                    "accuracy": float(acc),
                    "samples": int(seen),
                    "duration_ms": float(duration),
                },
                timeout=60,
            ).raise_for_status()
            self.tasks_done += 1
            print(f"[{self.name}] job {task['job_id']} epoch {task['epoch']} "
                  f"shard {task['shard_index']} — loss {loss:.4f}, acc {acc * 100:.1f}%, "
                  f"{duration:.0f} ms")
        except Exception as exc:
            print(f"[{self.name}] task {task.get('task_id')} failed: {exc}")
            try:
                self.session.post(
                    f"{self.api}/tasks/{task['task_id']}/fail",
                    json={"error": str(exc)}, timeout=15,
                )
            except Exception:
                pass
        finally:
            self.busy = False

    def loop(self) -> None:
        idle_notice = True
        while not stop_flag.is_set():
            try:
                r = self.session.get(
                    f"{self.api}/tasks/next", params={"node_id": self.node_id}, timeout=20
                )
                if r.status_code == 204:
                    if idle_notice:
                        print(f"[{self.name}] idle — waiting for work")
                        idle_notice = False
                    stop_flag.wait(self.poll)
                    continue
                if r.status_code == 404:
                    print(f"[{self.name}] node was removed from the cluster. Re-registering.")
                    self.register()
                    continue
                r.raise_for_status()
                idle_notice = True
                self.run_task(r.json())
            except requests.RequestException as exc:
                print(f"[{self.name}] coordinator unreachable ({exc}). Retrying in 5s.")
                stop_flag.wait(5)


def _total_memory_gb() -> float:
    try:
        return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / (1024**3)
    except (ValueError, OSError, AttributeError):
        return 8.0


def main() -> None:
    parser = argparse.ArgumentParser(description="Distributed ML Platform worker agent")
    parser.add_argument("--name", default=f"Worker-{socket.gethostname()[:8]}-{os.getpid()}")
    parser.add_argument("--server", default=DEFAULT_SERVER)
    parser.add_argument("--token", default=DEFAULT_TOKEN)
    parser.add_argument("--device", default="cpu", help="cpu, cuda:0, ...")
    parser.add_argument("--poll", type=float, default=1.5, help="seconds between polls when idle")
    args = parser.parse_args()

    agent = Agent(args.name, args.server, args.token, args.device, args.poll)

    def shutdown(*_):
        print(f"\n[{agent.name}] shutting down after {agent.tasks_done} tasks")
        stop_flag.set()

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    agent.register()
    threading.Thread(target=agent.heartbeat_loop, daemon=True).start()
    agent.loop()


if __name__ == "__main__":
    main()
