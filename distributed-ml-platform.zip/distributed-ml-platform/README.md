# Distributed Machine Learning Platform

A working control plane for training a model across several machines at once. A
coordinator holds the global weights, worker agents pull data shards over HTTP and
send gradients back, and a React dashboard shows the whole thing happening live.

Nothing in this project is simulated. The accuracy numbers on the dashboard come
from gradients that workers actually computed.

---

## What it does

The platform implements **synchronous data-parallel SGD** with a parameter server:

1. You create a training job and choose how many shards (workers) to split across.
2. The coordinator cuts the dataset into that many slices and opens round 1.
3. Every worker pulls a task, downloads *only its slice*, and computes a gradient
   starting from the same global weights.
4. When the last gradient arrives, the coordinator averages them — weighted by
   shard size — applies an SGD-with-momentum step, evaluates the new global model
   on a held-out split, writes a checkpoint, and opens the next round.

Workers hold no database and share no filesystem with the coordinator. Everything
moves over the REST API, which is what makes the cluster genuinely distributed
rather than multi-threaded.

### Also included

- **Fault tolerance.** A node that stops sending heartbeats is marked offline and
  the work it was holding is requeued for someone else. A task that fails three
  times fails the job with a clear reason.
- **Live telemetry.** WebSocket events push epoch results, node changes and log
  lines to every connected dashboard, with HTTP polling as a fallback.
- **JWT authentication** for humans, a separate shared cluster token for agents.
- **Datasets** either generated synthetically or uploaded as CSV.
- **Inference.** `POST /jobs/{id}/predict` runs the trained weights on new rows.

---

## Requirements

- Python 3.10 or newer
- Node.js 18 or newer (only for the dashboard)

---

## Running it

### 1. Backend

```bash
pip install -r requirements.txt
uvicorn backend.app.main:app --reload --port 8000
```

On first start it creates the database, an admin account and a 120,000-row
benchmark dataset. Generating the dataset takes about 20 seconds — that only
happens once.

Interactive API docs: <http://127.0.0.1:8000/docs>

Default sign-in: `admin@dmlp.local` / `admin12345`

### 2. Worker agents

Open a terminal per worker. Each one is an independent process:

```bash
python worker/agent.py --name Worker-01
python worker/agent.py --name Worker-02
python worker/agent.py --name Worker-03
python worker/agent.py --name Worker-04
```

Or use the helper scripts: `scripts/start_workers.sh 4` (macOS/Linux) or
`scripts\start_workers.bat 4` (Windows).

To run a worker on a **different machine**, point it at the coordinator's address:

```bash
python worker/agent.py --name Worker-05 --server http://192.168.1.10:8000
```

### 3. Dashboard

```bash
cd frontend
npm install
npm run dev
```

Open <http://localhost:5173>. Vite proxies `/api` and `/ws` to port 8000, so no
CORS setup is needed. The dashboard signs in automatically with the seeded
account.

### 4. Start a training run

Go to **Training Jobs → New Training Job**, pick a model, set the shard count to
match how many agents you started, and press Start Training. Watch the Dashboard,
Workers and Logs pages update as the rounds complete.

---

## Project layout

```
backend/app/
  main.py               FastAPI app, CORS, background health reaper
  config.py             Settings, all overridable by environment variable
  db.py                 SQLAlchemy engine and session handling
  models.py             Users, nodes, datasets, jobs, tasks, metrics, logs
  schemas.py            Request and response contracts
  security.py           PBKDF2 password hashing, JWT, cluster token
  seed.py               First-run admin account and benchmark dataset
  ml/
    model.py            NumPy neural network, forward/backward, serialisation
    data.py             Dataset generation, CSV parsing, sharding
  services/
    coordinator.py      Parameter server: dispatch, aggregation, evaluation
    catalog.py          Model catalogue shown in the dashboard
    events.py           WebSocket pub/sub hub
  routers/
    auth.py             Register, login, current user
    nodes.py            Node registration, heartbeat, drain, activate
    datasets.py         Create, upload, list, shard download
    jobs.py             Create, start, cancel, metrics, checkpoints, predict
    tasks.py            Worker protocol: claim, submit result, report failure
    cluster.py          Cluster summary, model catalogue, logs, WebSockets

worker/agent.py         Standalone worker agent
frontend/               React dashboard (Vite)
docs/API.md             Full endpoint reference
scripts/                Convenience launchers
```

---

## Configuration

Every setting has a working default. Override with environment variables:

| Variable | Default | Purpose |
| --- | --- | --- |
| `DMLP_DATABASE_URL` | SQLite in `storage/` | Point at PostgreSQL for a real deployment |
| `DMLP_JWT_SECRET` | development value | **Change this before deploying** |
| `DMLP_CLUSTER_TOKEN` | `dev-cluster-token` | Shared secret worker agents present |
| `DMLP_STORAGE` | `./storage` | Where datasets, weights and checkpoints live |
| `DMLP_HEARTBEAT_TIMEOUT` | `25` | Seconds of silence before a node is offline |
| `DMLP_TASK_LEASE_TIMEOUT` | `120` | Seconds before an unfinished task is requeued |

---

## How the maths works

Each worker runs `local_steps` mini-batches on its shard and returns the averaged
gradient **g_k** along with the number of samples it saw, **n_k**. The coordinator
computes

```
g = Σ (n_k / Σn) · g_k
v = μ·v − η·g
w = w + v
```

Because every worker starts the round from identical weights, averaging gradients
this way is mathematically equivalent to one large-batch SGD step over the whole
dataset — which is exactly the guarantee real frameworks rely on. The model itself
is a ReLU network with a softmax output and cross-entropy loss, written directly in
NumPy so the gradient computation is visible rather than hidden behind a framework.

---

## Verified result

A 20-epoch run on the seeded dataset with four agents:

| Epoch | Train loss | Validation accuracy |
| --- | --- | --- |
| 1 | 2.8330 | 12.63% |
| 5 | 1.2939 | 74.30% |
| 10 | 0.2943 | 95.28% |
| 15 | 0.1115 | 97.63% |
| 20 | 0.0728 | 98.28% |

Reproduce it by starting four agents and creating a "CNN Image Model" job with 4
shards and 20 epochs.

---

## Where it would go next

Honest limitations worth naming in a report or viva:

- Rounds are **synchronous**, so the slowest worker sets the pace. Asynchronous or
  stale-synchronous updates would remove that bottleneck.
- Gradients travel as uncompressed float32. Production systems quantise or sparsify
  them, which is the single biggest bandwidth win available here.
- Models are dense feedforward networks. Convolutional and attention layers would
  need real tensor kernels rather than NumPy matrix multiplies.
- One coordinator means one point of failure. Sharding the parameter server or
  electing a leader would fix that.
