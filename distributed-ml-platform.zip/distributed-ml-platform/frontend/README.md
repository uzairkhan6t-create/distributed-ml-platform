# Dashboard

React + Vite frontend for the Distributed ML Platform.

```bash
npm install
npm run dev
```

Opens on <http://localhost:5173>. Vite proxies `/api` and `/ws` through to the
coordinator on port 8000, so start the backend first.

## How it gets its data

Every page reads through `src/api.js`. Nothing is stored in the browser except
display preferences and the auth token — jobs, workers, models and logs all come
from the API.

- `src/api.js` — fetch wrapper, automatic sign-in and token refresh on 401,
  WebSocket stream with exponential-backoff reconnect, and adapters that reshape
  API resources into the props the components expect.
- `src/App.jsx` — page routing, data loading, and the actions that create, cancel
  and delete jobs or drain and restore workers.
- `src/App.css` — styling.

Updates arrive two ways: a WebSocket pushes events the moment they happen, and a
3-second poll runs alongside it so the dashboard stays correct even if the socket
drops.

## Configuration

Copy `.env.example` to `.env.local` to change where the API lives:

```
VITE_BACKEND_URL=http://192.168.1.10:8000
```

## Build

```bash
npm run build      # output in dist/
npm run preview
```
