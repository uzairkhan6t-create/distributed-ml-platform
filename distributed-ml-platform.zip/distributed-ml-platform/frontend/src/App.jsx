import { useState, useEffect, useCallback, useRef } from "react";
import "./App.css";
import {
  api,
  ensureSession,
  openClusterStream,
  adaptJob,
  adaptNode,
  adaptLog,
} from "./api";

// =====================================================
// LOCAL PREFERENCES
// Only display preferences live in the browser. Jobs,
// workers, models and logs all come from the API.
// =====================================================

const SETTINGS_KEY = "dai_settings";

function loadSettings() {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    return raw ? { ...defaultSettings, ...JSON.parse(raw) } : defaultSettings;
  } catch {
    return defaultSettings;
  }
}

const defaultSettings = {
  platformName: "Distributed AI",
  autoRefresh: true,
  notifications: true,
  theme: "light",
};

const POLL_INTERVAL_MS = 3000;

// =====================================================
// MAIN APP
// =====================================================

function App() {
  const [activePage, setActivePage] = useState("Dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [trainingJobs, setTrainingJobs] = useState([]);
  const [workersData, setWorkersData] = useState([]);
  const [models, setModels] = useState([]);
  const [logs, setLogs] = useState([]);
  const [summary, setSummary] = useState(null);
  const [settings, setSettings] = useState(loadSettings);
  const [notifications, setNotifications] = useState([]);

  const [connection, setConnection] = useState("connecting"); // connecting | live | down
  const [banner, setBanner] = useState(null);                 // { type, text }
  const [loading, setLoading] = useState(true);

  const [notifOpen, setNotifOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [prefillModel, setPrefillModel] = useState(null);

  const notifyRef = useRef(settings.notifications);
  notifyRef.current = settings.notifications;

  const menuItems = [
    "Dashboard",
    "Training Jobs",
    "Workers",
    "Models",
    "Logs",
    "System Monitor",
    "Settings",
    "Help",
  ];

  // =========================
  // PREFERENCES PERSIST
  // =========================

  useEffect(() => {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    document.body.classList.toggle("dark-mode", settings.theme === "dark");
  }, [settings.theme]);

  // =========================
  // NOTIFICATIONS
  // =========================

  const addNotification = useCallback((text) => {
    if (!notifyRef.current) return;
    const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    setNotifications((prev) => [{ id: Date.now() + Math.random(), text, time, read: false }, ...prev].slice(0, 25));
  }, []);

  function markAllNotificationsRead() {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }

  const unreadCount = notifications.filter((n) => !n.read).length;

  // =========================
  // DATA LOADING
  // =========================

  const loadJobs = useCallback(async () => {
    const rows = await api.jobs();
    setTrainingJobs(rows.map(adaptJob));
  }, []);

  const loadWorkers = useCallback(async () => {
    const rows = await api.nodes();
    setWorkersData(rows.map(adaptNode));
  }, []);

  const loadSummary = useCallback(async () => {
    setSummary(await api.summary());
  }, []);

  const loadLogs = useCallback(async (search = "") => {
    const rows = await api.logs(search);
    setLogs(rows.map(adaptLog));
  }, []);

  const refreshAll = useCallback(async () => {
    try {
      await Promise.all([loadJobs(), loadWorkers(), loadSummary()]);
      setConnection((c) => (c === "down" ? "live" : c));
      setBanner(null);
    } catch (err) {
      setConnection("down");
      setBanner({ type: "error", text: err.message });
    }
  }, [loadJobs, loadWorkers, loadSummary]);

  // initial boot
  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        await ensureSession();
        const [jobRows, nodeRows, modelRows, logRows, sum] = await Promise.all([
          api.jobs(),
          api.nodes(),
          api.models(),
          api.logs(),
          api.summary(),
        ]);
        if (cancelled) return;
        setTrainingJobs(jobRows.map(adaptJob));
        setWorkersData(nodeRows.map(adaptNode));
        setModels(modelRows);
        setLogs(logRows.map(adaptLog));
        setSummary(sum);
        setConnection("live");
        setBanner(null);
      } catch {
        if (cancelled) return;
        setConnection("down");
        setBanner({
          type: "error",
          text: "Cannot reach the coordinator. Start it with: uvicorn backend.app.main:app --port 8000",
        });
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  // live event stream
  useEffect(() => {
    const close = openClusterStream((message) => {
      const { event, data } = message;

      if (event === "log") {
        setLogs((prev) => [adaptLog(data), ...prev].slice(0, 300));
        if (data.level === "warning" || data.level === "error") addNotification(data.message);
        return;
      }

      if (event === "job_completed") {
        addNotification(`Job ${data.job_id} finished at ${(data.best_val_accuracy * 100).toFixed(1)}% accuracy`);
      }

      if (event === "epoch_completed" || event.startsWith("job_")) {
        loadJobs().catch(() => {});
        loadSummary().catch(() => {});
      }

      if (event === "node_registered" || event === "nodes_changed" || event === "heartbeat") {
        loadWorkers().catch(() => {});
      }
    });

    return close;
  }, [addNotification, loadJobs, loadWorkers, loadSummary]);

  // polling fallback — keeps the dashboard correct even if the socket drops
  useEffect(() => {
    if (!settings.autoRefresh) return;
    const id = setInterval(refreshAll, POLL_INTERVAL_MS);
    return () => clearInterval(id);
  }, [settings.autoRefresh, refreshAll]);

  // =========================
  // JOB ACTIONS
  // =========================

  async function createJob(model, workerCount, epochs) {
    try {
      const created = await api.createJob({
        model,
        world_size: Number(workerCount),
        epochs: Number(epochs) || 20,
      });
      await refreshAll();
      addNotification(`Job ${created.id} (${created.model_name}) started on ${created.world_size} workers`);
      setBanner({ type: "success", text: `Training started: ${created.name}` });
      setPrefillModel(null);
    } catch (err) {
      setBanner({ type: "error", text: err.message });
    }
  }

  async function cancelJob(job) {
    try {
      await api.cancelJob(job.rawId);
      await refreshAll();
    } catch (err) {
      setBanner({ type: "error", text: err.message });
    }
  }

  async function deleteJob(job) {
    try {
      await api.deleteJob(job.rawId);
      await refreshAll();
    } catch (err) {
      setBanner({ type: "error", text: err.message });
    }
  }

  // =========================
  // WORKER ACTIONS
  // =========================

  async function refreshWorkers() {
    try {
      await Promise.all([loadWorkers(), loadSummary()]);
    } catch (err) {
      setBanner({ type: "error", text: err.message });
    }
  }

  async function toggleWorkerStatus(worker) {
    try {
      if (worker.state === "draining" || worker.status === "Offline") {
        await api.activateNode(worker.id);
      } else {
        await api.drainNode(worker.id);
      }
      await loadWorkers();
    } catch (err) {
      setBanner({ type: "error", text: err.message });
    }
  }

  // =========================
  // MODEL ACTIONS
  // =========================

  function useModel(name) {
    setPrefillModel(name);
    setActivePage("Training Jobs");
  }

  // =========================
  // SETTINGS ACTIONS
  // =========================

  function saveSettings(newSettings) {
    setSettings(newSettings);
  }

  function resetSettings() {
    setSettings(defaultSettings);
  }

  function toggleTheme() {
    setSettings((prev) => ({ ...prev, theme: prev.theme === "dark" ? "light" : "dark" }));
    setUserMenuOpen(false);
  }

  function clearAllData() {
    if (!window.confirm("This clears your saved display preferences in this browser. Training jobs on the server are not affected. Continue?")) {
      return;
    }
    localStorage.removeItem(SETTINGS_KEY);
    localStorage.removeItem("dai_token");
    window.location.reload();
  }

  // =========================
  // DERIVED STATS
  // =========================

  const onlineWorkers = workersData.filter((w) => w.status === "Online").length;

  function averageStat(key) {
    if (summary) {
      if (key === "cpu") return Math.round(summary.avg_cpu);
      if (key === "gpuUsage") return Math.round(summary.avg_gpu);
      if (key === "memory") return Math.round(summary.avg_memory);
    }
    const online = workersData.filter((w) => w.status === "Online");
    if (online.length === 0) return 0;
    return Math.round(online.reduce((sum, w) => sum + (w[key] || 0), 0) / online.length);
  }

  // =========================
  // PAGE ROUTING
  // =========================

  function goToPage(page) {
    setActivePage(page);
    setSidebarOpen(false);
  }

  const renderPage = () => {
    switch (activePage) {
      case "Dashboard":
        return (
          <Dashboard
            jobs={trainingJobs}
            workers={workersData}
            onlineWorkers={onlineWorkers}
            averageStat={averageStat}
            summary={summary}
            loading={loading}
            goToWorkers={() => goToPage("Workers")}
          />
        );

      case "Training Jobs":
        return (
          <TrainingJobs
            jobs={trainingJobs}
            models={models}
            onCreateJob={createJob}
            onCancelJob={cancelJob}
            onDeleteJob={deleteJob}
            prefillModel={prefillModel}
            clearPrefill={() => setPrefillModel(null)}
          />
        );

      case "Workers":
        return (
          <Workers
            workers={workersData}
            onToggle={toggleWorkerStatus}
            onRefresh={refreshWorkers}
          />
        );

      case "Models":
        return <Models models={models} onUseModel={useModel} />;

      case "Logs":
        return <Logs entries={logs} onSearch={loadLogs} />;

      case "System Monitor":
        return (
          <SystemMonitor
            averageStat={averageStat}
            summary={summary}
            onRefresh={refreshWorkers}
          />
        );

      case "Settings":
        return (
          <Settings
            settings={settings}
            onSave={saveSettings}
            onReset={resetSettings}
          />
        );

      case "Help":
        return <Help onClearData={clearAllData} />;

      default:
        return (
          <Dashboard
            jobs={trainingJobs}
            workers={workersData}
            onlineWorkers={onlineWorkers}
            averageStat={averageStat}
            summary={summary}
            loading={loading}
            goToWorkers={() => goToPage("Workers")}
          />
        );
    }
  };

  return (
    <div className="app">

      {/* MOBILE SIDEBAR OVERLAY */}

      {sidebarOpen && (
        <div className="sidebar-overlay" onClick={() => setSidebarOpen(false)}></div>
      )}

      {/* ================= SIDEBAR ================= */}

      <aside className={`sidebar ${sidebarOpen ? "open" : ""}`}>

        <div className="logo">
          <div className="logo-icon">AI</div>

          <div>
            <h2>{settings.platformName}</h2>
            <p>Training Platform</p>
          </div>
        </div>


        {/* NAVIGATION */}

        <nav className="navigation">

          {menuItems.map((item) => (
            <button
              key={item}
              className={`nav-item ${activePage === item ? "active" : ""}`}
              onClick={() => goToPage(item)}
            >
              <span className="nav-icon">{getIcon(item)}</span>
              {item}
            </button>
          ))}

        </nav>


        {/* SIDEBAR FOOTER */}

        <div className="sidebar-footer">
          <div className="system-online">
            <span className="online-dot"></span>
            <div>
              <strong>System Online</strong>
              <small>All systems normal</small>
            </div>
          </div>
        </div>

      </aside>


      {/* ================= MAIN ================= */}

      <main className="main-content">

        {/* TOPBAR */}

        <header className="topbar">

          <div className="topbar-left">

            <button
              className="menu-toggle"
              aria-label="Toggle menu"
              onClick={() => setSidebarOpen((v) => !v)}
            >
              ☰
            </button>

            <div>
              <h1>{activePage}</h1>
              <p>{getDescription(activePage)}</p>
            </div>

          </div>


          <div className="user-area">

            <div className="notification-wrap">

              <button
                className="notification"
                onClick={() => {
                  setNotifOpen((v) => !v);
                  setUserMenuOpen(false);
                }}
              >
                🔔
                {unreadCount > 0 && (
                  <span className="notif-badge">{unreadCount > 9 ? "9+" : unreadCount}</span>
                )}
              </button>

              {notifOpen && (
                <div className="notif-dropdown">

                  <div className="notif-dropdown-header">
                    <strong>Notifications</strong>
                    <button className="link-btn" onClick={markAllNotificationsRead}>
                      Mark all read
                    </button>
                  </div>

                  <div className="notif-list">
                    {notifications.length === 0 ? (
                      <div className="notif-empty">No notifications yet</div>
                    ) : (
                      notifications.map((n) => (
                        <div key={n.id} className={`notif-item ${n.read ? "" : "unread"}`}>
                          <p>{n.text}</p>
                          <small>{n.time}</small>
                        </div>
                      ))
                    )}
                  </div>

                </div>
              )}

            </div>

            <div className="user-wrap">

              <button
                className="user"
                onClick={() => {
                  setUserMenuOpen((v) => !v);
                  setNotifOpen(false);
                }}
              >
                <div className="avatar">U</div>
                <div className="user-text">
                  <strong>Uzair</strong>
                  <small>Web Developer</small>
                </div>
              </button>

              {userMenuOpen && (
                <div className="user-dropdown">
                  <a href="#" onClick={(e) => { e.preventDefault(); goToPage("Settings"); setUserMenuOpen(false); }}>
                    👤 Profile
                  </a>
                  <a href="#" onClick={(e) => { e.preventDefault(); toggleTheme(); }}>
                    🌓 Toggle theme
                  </a>
                  <a href="#" onClick={(e) => { e.preventDefault(); setUserMenuOpen(false); alert("You have been logged out (demo only — no backend auth is connected yet)."); }}>
                    🚪 Log out
                  </a>
                </div>
              )}

            </div>

          </div>

        </header>


        {/* PAGE */}

        <section className="page-container">

          {banner && (
            <div className={`alert alert-${banner.type}`} role="status">
              <span>{banner.text}</span>
              <button className="alert-close" onClick={() => setBanner(null)} aria-label="Dismiss">×</button>
            </div>
          )}

          {connection === "down" && !banner && (
            <div className="alert alert-error" role="status">
              <span>Lost contact with the coordinator. Retrying automatically.</span>
            </div>
          )}

          {renderPage()}
        </section>

      </main>

    </div>
  );
}


// =====================================================
// ICONS
// =====================================================

function getIcon(item) {
  const icons = {
    "Dashboard": "▦",
    "Training Jobs": "⚙",
    "Workers": "▥",
    "Models": "◈",
    "Logs": "▤",
    "System Monitor": "◉",
    "Settings": "⚙",
    "Help": "?",
  };
  return icons[item];
}


// =====================================================
// PAGE DESCRIPTIONS
// =====================================================

function getDescription(page) {
  const descriptions = {
    "Dashboard": "Monitor your distributed AI training system",
    "Training Jobs": "Create and monitor machine learning training jobs",
    "Workers": "Monitor distributed computing workers",
    "Models": "Manage AI models used for training",
    "Logs": "View training and system activity",
    "System Monitor": "Monitor CPU, GPU and memory resources",
    "Settings": "Configure your distributed AI platform",
    "Help": "Information about the training platform",
  };
  return descriptions[page];
}


// =====================================================
// DASHBOARD
// =====================================================

function Dashboard({ jobs, workers, onlineWorkers, averageStat, summary, loading, goToWorkers }) {
  const running = jobs.filter((j) => j.status === "Running");
  const featured = running[0] || jobs[0];
  const [curve, setCurve] = useState([]);
  const featuredId = featured ? featured.rawId : null;

  // Pull the real learning curve of the featured job.
  useEffect(() => {
    if (!featuredId) {
      setCurve([]);
      return;
    }
    let cancelled = false;

    async function pull() {
      try {
        const metrics = await api.jobMetrics(featuredId);
        if (!cancelled) setCurve(metrics);
      } catch {
        /* the banner already reports connection problems */
      }
    }

    pull();
    const id = setInterval(pull, 3000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [featuredId]);

  return (
    <>

      {/* SYSTEM STATUS */}

      <div className="status-banner">
        <div className="status-left">
          <span className="big-online-dot"></span>
          <div>
            <strong>
              {onlineWorkers > 0
                ? `Cluster online — ${onlineWorkers} worker${onlineWorkers === 1 ? "" : "s"} ready`
                : "No workers connected"}
            </strong>
            <p>
              {onlineWorkers > 0
                ? `${running.length} job${running.length === 1 ? "" : "s"} training, ${summary ? summary.tasks_completed.toLocaleString() : 0} shards processed`
                : "Start an agent: python worker/agent.py --name Worker-01"}
            </p>
          </div>
        </div>
        <span>{loading ? "Loading…" : `Updated ${new Date().toLocaleTimeString()}`}</span>
      </div>


      {/* STATISTICS */}

      <div className="stats-grid">

        <StatCard
          icon="◉"
          title="Active Workers"
          value={`${onlineWorkers} / ${workers.length}`}
          change={`${workers.length ? Math.round((onlineWorkers / workers.length) * 100) : 0}% online`}
          type="blue"
        />

        <StatCard
          icon="◈"
          title="Training Jobs"
          value={jobs.length}
          change={`${running.length} running now`}
          type="purple"
        />

        <StatCard
          icon="✓"
          title="Accuracy"
          value={featured ? featured.accuracy : "0%"}
          change="Latest job"
          type="green"
        />

        <StatCard
          icon="◷"
          title="Throughput"
          value={summary ? `${Math.round(summary.throughput).toLocaleString()}/s` : "0/s"}
          change="Samples across the fleet"
          type="orange"
        />

      </div>


      {/* TWO COLUMN SECTION */}

      <div className="two-column">

        {/* TRAINING */}

        <div className="card">

          <div className="card-header">
            <div>
              <h2>Current Training</h2>
              <p>Model training progress</p>
            </div>
            <span className="running">{featured ? featured.status.toUpperCase() : "IDLE"}</span>
          </div>

          {featured ? (
            <>
              <div className="model-details">
                <div>
                  <span>Model</span>
                  <strong>{featured.model}</strong>
                </div>
                <div>
                  <span>Dataset</span>
                  <strong>{featured.dataset || "—"}</strong>
                </div>
              </div>

              <div className="progress-header">
                <span>Training Progress</span>
                <strong>{featured.progress}%</strong>
              </div>

              <div className="progress-bar">
                <div className="progress-fill" style={{ width: `${featured.progress}%` }}></div>
              </div>

              <div className="epoch">
                <span>Job {featured.id}</span>
                <span>Epoch {featured.epoch} / {featured.epochs}</span>
              </div>

              <div className="metrics">
                <Metric title="Accuracy" value={featured.accuracy} />
                <Metric title="Val loss" value={featured.loss ? featured.loss.toFixed(4) : "—"} />
                <Metric title="Workers" value={featured.workers} />
              </div>
            </>
          ) : (
            <p style={{ color: "#94a3b8", padding: "20px 0" }}>
              No training jobs yet. Create one from the Training Jobs page.
            </p>
          )}

        </div>


        {/* WORKERS */}

        <div className="card">

          <div className="card-header">
            <div>
              <h2>Workers</h2>
              <p>Distributed training nodes</p>
            </div>
            <span className="view-all" onClick={goToWorkers}>View All</span>
          </div>

          {workers.slice(0, 4).map((w) => (
            <WorkerRow key={w.name} name={w.name} gpu={w.gpu} status={w.status} />
          ))}

        </div>

      </div>


      {/* CHART + RESOURCES */}

      <div className="two-column">

        <div className="card">
          <div className="card-header">
            <div>
              <h2>Training Accuracy</h2>
              <p>Model accuracy over epochs</p>
            </div>
          </div>

          <AccuracyChart points={curve} />
        </div>

        <div className="card">
          <div className="card-header">
            <div>
              <h2>Resource Usage</h2>
              <p>Current system utilization</p>
            </div>
          </div>

          <ResourceBar name="CPU Usage" value={`${averageStat("cpu")}%`} />
          <ResourceBar name="GPU Usage" value={`${averageStat("gpuUsage")}%`} />
          <ResourceBar name="Memory" value={`${averageStat("memory")}%`} />
        </div>

      </div>

    </>
  );
}



// =====================================================
// ACCURACY CHART
// Plots the real per-epoch validation accuracy returned
// by GET /jobs/{id}/metrics. No canvas library needed.
// =====================================================

function AccuracyChart({ points }) {
  if (!points || points.length === 0) {
    return (
      <div className="chart chart-empty">
        <p>Accuracy appears here once the first epoch is aggregated.</p>
      </div>
    );
  }

  const W = 100;
  const H = 100;
  const maxEpoch = Math.max(...points.map((p) => p.epoch), 1);

  const toXY = (p, i) => {
    const x = points.length === 1 ? 0 : (i / (points.length - 1)) * W;
    const y = H - p.val_accuracy * H;
    return [x, y];
  };

  const line = points.map((p, i) => toXY(p, i).join(",")).join(" ");
  const area = `0,${H} ${line} ${W},${H}`;
  const latest = points[points.length - 1];

  return (
    <div className="chart">
      <svg className="chart-svg" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" role="img"
           aria-label={`Validation accuracy across ${points.length} epochs`}>
        {[0.25, 0.5, 0.75].map((g) => (
          <line key={g} x1="0" x2={W} y1={H * g} y2={H * g} className="chart-grid" />
        ))}
        <polygon points={area} className="chart-area" />
        <polyline points={line} className="chart-path" />
        {points.length <= 40 &&
          points.map((p, i) => {
            const [x, y] = toXY(p, i);
            return <circle key={p.epoch} cx={x} cy={y} r="1.4" className="chart-dot" />;
          })}
      </svg>

      <div className="chart-values">
        <span>Epoch 1</span>
        <span>{(latest.val_accuracy * 100).toFixed(1)}% at epoch {latest.epoch}</span>
        <span>Epoch {maxEpoch}</span>
      </div>
    </div>
  );
}

// =====================================================
// STAT CARD
// =====================================================

function StatCard({ icon, title, value, change, type }) {
  return (
    <div className="stat-card">
      <div className={`stat-icon ${type}`}>{icon}</div>
      <div>
        <p>{title}</p>
        <h2>{value}</h2>
        <small>{change}</small>
      </div>
    </div>
  );
}


// =====================================================
// METRIC
// =====================================================

function Metric({ title, value }) {
  return (
    <div className="metric">
      <span>{title}</span>
      <strong>{value}</strong>
    </div>
  );
}


// =====================================================
// WORKER ROW (dashboard mini list)
// =====================================================

function WorkerRow({ name, gpu, status }) {
  return (
    <div className="worker-row">
      <div className="worker-left">
        <div className="worker-avatar">{name.slice(-2)}</div>
        <div>
          <strong>{name}</strong>
          <small>GPU • {gpu}</small>
        </div>
      </div>

      <span className={status === "Online" ? "online-text" : "offline-text"}>
        ● {status}
      </span>
    </div>
  );
}


// =====================================================
// RESOURCE BAR
// =====================================================

function ResourceBar({ name, value }) {
  return (
    <div className="resource">
      <div className="resource-header">
        <span>{name}</span>
        <strong>{value}</strong>
      </div>
      <div className="resource-bar">
        <div className="resource-fill" style={{ width: value }}></div>
      </div>
    </div>
  );
}


// =====================================================
// TRAINING JOBS
// =====================================================

function TrainingJobs({ jobs, models, onCreateJob, onCancelJob, onDeleteJob, prefillModel, clearPrefill }) {
  const [formOpen, setFormOpen] = useState(false);
  const [model, setModel] = useState("Distributed Transformer");
  const [workerCount, setWorkerCount] = useState(4);
  const [epochs, setEpochs] = useState(20);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState("");
  const [searchText, setSearchText] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");

  useEffect(() => {
    if (prefillModel) {
      setModel(prefillModel);
      setFormOpen(true);
      clearPrefill();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prefillModel]);

  async function handleSubmit() {
    const count = Number(workerCount);
    const rounds = Number(epochs);

    if (!count || count < 1) {
      setFormError("Set at least 1 worker shard.");
      return;
    }
    if (count > 20) {
      setFormError("Use 20 shards or fewer per job.");
      return;
    }
    if (!rounds || rounds < 1 || rounds > 200) {
      setFormError("Epochs must be between 1 and 200.");
      return;
    }

    setFormError("");
    setSubmitting(true);
    await onCreateJob(model, count, rounds);
    setSubmitting(false);
    setFormOpen(false);
    setWorkerCount(4);
  }

  const filteredJobs = jobs.filter((job) => {
    const matchesText =
      job.id.toLowerCase().includes(searchText.toLowerCase()) ||
      job.model.toLowerCase().includes(searchText.toLowerCase());
    const matchesStatus = statusFilter === "All" || job.status === statusFilter;
    return matchesText && matchesStatus;
  });

  return (
    <div className="card">

      <div className="card-header">
        <div>
          <h2>Training Jobs</h2>
          <p>Manage distributed AI training jobs</p>
        </div>
        <button className="primary-button" onClick={() => setFormOpen((v) => !v)}>
          + New Training Job
        </button>
      </div>

      {formOpen && (
        <div className="job-form">

          <label>Select Model</label>
          <select value={model} onChange={(e) => setModel(e.target.value)}>
            {(models.length ? models : [{ key: "d", name: "Distributed Transformer" }]).map((m) => (
              <option key={m.key || m.name}>{m.name}</option>
            ))}
          </select>

          <label>Data shards (parallel workers)</label>
          <input
            type="number"
            min="1"
            max="20"
            value={workerCount}
            onChange={(e) => setWorkerCount(e.target.value)}
          />

          <label>Epochs</label>
          <input
            type="number"
            min="1"
            max="200"
            value={epochs}
            onChange={(e) => setEpochs(e.target.value)}
          />

          {formError && <p className="form-error">{formError}</p>}

          <div className="form-buttons">
            <button className="primary-button" onClick={handleSubmit} disabled={submitting}>
              {submitting ? "Starting…" : "Start Training"}
            </button>
            <button className="cancel-button" onClick={() => setFormOpen(false)}>Cancel</button>
          </div>

        </div>
      )}

      <div className="jobs-toolbar">
        <input
          type="text"
          placeholder="Search jobs by ID or model..."
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
        />

        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option>All</option>
          <option>Queued</option>
          <option>Running</option>
          <option>Completed</option>
          <option>Cancelled</option>
          <option>Failed</option>
        </select>
      </div>

      <div className="table-container">

        {filteredJobs.length === 0 ? (
          <p style={{ padding: "30px 0", textAlign: "center", color: "#94a3b8" }}>
            {jobs.length === 0
              ? "No training jobs yet. Create one to put the fleet to work."
              : "No jobs match your search."}
          </p>
        ) : (
          <table>

            <thead>
              <tr>
                <th>Job ID</th>
                <th>Model</th>
                <th>Workers</th>
                <th>Progress</th>
                <th>Accuracy</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              {filteredJobs.map((job) => {
                const statusClass =
                  job.status === "Running" ? "running-status" :
                  job.status === "Completed" ? "completed" : "cancelled";
                const busy = job.status === "Running" || job.status === "Queued";

                return (
                  <tr key={job.id}>
                    <td>#{job.id}</td>
                    <td>{job.model}</td>
                    <td>{job.workers}</td>
                    <td>
                      <div className="job-progress">
                        <div className="job-progress-fill" style={{ width: `${job.progress}%` }}></div>
                      </div>
                      {job.progress}%
                    </td>
                    <td>{job.accuracy}</td>
                    <td><span className={`status ${statusClass}`}>{job.status}</span></td>
                    <td>
                      {busy ? (
                        <button className="action-btn" onClick={() => onCancelJob(job)}>Cancel</button>
                      ) : (
                        <button className="action-btn" onClick={() => onDeleteJob(job)}>Delete</button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>

          </table>
        )}

      </div>

    </div>
  );
}


// =====================================================
// WORKERS PAGE
// =====================================================

function Workers({ workers, onToggle, onRefresh }) {
  const online = workers.filter((w) => w.status === "Online").length;
  const offline = workers.length - online;
  const onlineWorkers = workers.filter((w) => w.status === "Online");
  const avgGpu = onlineWorkers.length
    ? Math.round(onlineWorkers.reduce((sum, w) => sum + w.gpuUsage, 0) / onlineWorkers.length)
    : 0;

  return (
    <>

      <div className="card-header" style={{ marginBottom: 20 }}>
        <div>
          <h2>Worker Fleet</h2>
          <p>Live status of distributed training nodes</p>
        </div>
        <button className="primary-button" onClick={onRefresh}>↻ Refresh Workers</button>
      </div>

      <div className="stats-grid">
        <StatCard icon="◉" title="Total Workers" value={workers.length} change="Registered workers" type="blue" />
        <StatCard icon="✓" title="Online" value={online} change="Workers available" type="green" />
        <StatCard icon="!" title="Offline" value={offline} change="Workers unavailable" type="orange" />
        <StatCard icon="GPU" title="Average GPU" value={`${avgGpu}%`} change="Current utilization" type="purple" />
      </div>

      <div className="worker-grid">
        {workers.length === 0 ? (
          <div className="card empty-state">
            <h3>No workers have joined yet</h3>
            <p>Start an agent on any machine that can reach the coordinator:</p>
            <code>python worker/agent.py --name Worker-01</code>
          </div>
        ) : (
          workers.map((w) => <WorkerCard key={w.name} worker={w} onToggle={onToggle} />)
        )}
      </div>

    </>
  );
}


// =====================================================
// WORKER CARD
// =====================================================

function WorkerCard({ worker, onToggle }) {
  const { name, gpu, cpu, gpuUsage, memory, status, job, state, tasksCompleted, host } = worker;
  const label = state === "draining" ? "Draining" : status;

  return (
    <div className="worker-card">

      <div className="worker-card-header">
        <div className="worker-avatar large">{name.slice(-2)}</div>
        <div>
          <h3>{name}</h3>
          <span className={status === "Online" ? "online-text" : "offline-text"}>
            ● {label}
          </span>
        </div>
        <button className="toggle-btn" onClick={() => onToggle(worker)}>
          {state === "draining" || status === "Offline" ? "Return to pool" : "Drain"}
        </button>
      </div>

      <p className="gpu-name">Device: {gpu}</p>
      <p className="gpu-name">Host: {host || "unknown"}</p>
      <p className="gpu-name">Work: {job} • {tasksCompleted} shards done</p>

      <div className="worker-stat">
        <span>CPU Usage</span>
        <strong>{cpu}%</strong>
      </div>

      <div className="worker-stat">
        <span>GPU Usage</span>
        <strong>{gpuUsage}%</strong>
      </div>

      <div className="worker-stat">
        <span>Memory</span>
        <strong>{memory}%</strong>
      </div>

    </div>
  );
}


// =====================================================
// MODELS
// =====================================================

function Models({ models, onUseModel }) {
  if (!models || models.length === 0) {
    return (
      <div className="card empty-state">
        <h3>Model catalogue unavailable</h3>
        <p>The coordinator returns the architectures it can train. Check that the API is running.</p>
      </div>
    );
  }

  return (
    <div className="model-grid">
      {models.map((model) => (
        <div className="model-card" key={model.key}>

          <div className="model-icon">◈</div>

          <h3>{model.name}</h3>
          <p>{model.description}</p>

          <div className="model-card-footer">
            <span className="available">
              {model.architecture === "logreg" ? "Linear" : `${model.hidden_layers.join(" → ")} hidden`}
            </span>
            <span className="model-params">{model.params}</span>
          </div>

          <button className="primary-button model-use-btn" onClick={() => onUseModel(model.name)}>
            Use this model
          </button>

        </div>
      ))}
    </div>
  );
}


// =====================================================
// LOGS
// =====================================================

function Logs({ entries, onSearch }) {
  const [searchText, setSearchText] = useState("");

  // Ask the server to filter, so search covers the full history rather than
  // only the entries already streamed into this page.
  useEffect(() => {
    const id = setTimeout(() => onSearch(searchText).catch(() => {}), 300);
    return () => clearTimeout(id);
  }, [searchText, onSearch]);

  return (
    <div className="card">

      <div className="card-header">
        <div>
          <h2>System Logs</h2>
          <p>Coordinator, cluster and training activity</p>
        </div>
      </div>

      <div className="logs-toolbar">
        <input
          type="text"
          placeholder="Search logs..."
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
        />
      </div>

      <div className="log-box">
        {entries.length === 0 ? (
          <div style={{ color: "#94a3b8" }}>
            {searchText ? "No log entries match your search." : "No activity recorded yet."}
          </div>
        ) : (
          entries.map((entry) => (
            <div
              key={entry.id}
              className={`log-line ${entry.type === "warning" ? "log-warning" : entry.type === "success" ? "log-success" : ""}`}
            >
              [{entry.time}] {entry.text}
            </div>
          ))
        )}
      </div>

    </div>
  );
}


// =====================================================
// SYSTEM MONITOR
// =====================================================

function SystemMonitor({ averageStat, summary, onRefresh }) {
  const cpu = averageStat("cpu");
  const gpu = averageStat("gpuUsage");
  const mem = averageStat("memory");
  const shards = summary ? summary.tasks_completed : 0;
  const samples = summary ? summary.samples_processed : 0;

  return (
    <>

      <div className="stats-grid">
        <StatCard icon="CPU" title="CPU Usage" value={`${cpu}%`} change={cpu > 85 ? "High" : "Normal"} type="blue" />
        <StatCard icon="GPU" title="GPU Usage" value={`${gpu}%`} change={gpu > 85 ? "High" : "Normal"} type="purple" />
        <StatCard icon="RAM" title="Memory" value={`${mem}%`} change={mem > 85 ? "High" : "Normal"} type="green" />
        <StatCard
          icon="NET"
          title="Shards processed"
          value={shards.toLocaleString()}
          change={`${samples.toLocaleString()} samples`}
          type="orange"
        />
      </div>

      <div className="card">

        <div className="card-header">
          <div>
            <h2>Resource Monitoring</h2>
            <p>Current infrastructure utilization</p>
          </div>
          <button className="view-all" onClick={onRefresh} style={{ background: "none", border: "none", cursor: "pointer" }}>
            ↻ Refresh
          </button>
        </div>

        <ResourceBar name="CPU Usage" value={`${cpu}%`} />
        <ResourceBar name="GPU Usage" value={`${gpu}%`} />
        <ResourceBar name="Memory Usage" value={`${mem}%`} />
        <ResourceBar
          name="Fleet availability"
          value={`${summary && summary.nodes_total ? Math.round((summary.nodes_online / summary.nodes_total) * 100) : 0}%`}
        />

      </div>

    </>
  );
}


// =====================================================
// SETTINGS
// =====================================================

function Settings({ settings, onSave, onReset }) {
  const [platformName, setPlatformName] = useState(settings.platformName);
  const [autoRefresh, setAutoRefresh] = useState(settings.autoRefresh);
  const [notificationsOn, setNotificationsOn] = useState(settings.notifications);
  const [darkMode, setDarkMode] = useState(settings.theme === "dark");
  const [showConfirm, setShowConfirm] = useState(false);

  useEffect(() => {
    setPlatformName(settings.platformName);
    setAutoRefresh(settings.autoRefresh);
    setNotificationsOn(settings.notifications);
    setDarkMode(settings.theme === "dark");
  }, [settings]);

  function handleSave() {
    onSave({
      platformName: platformName.trim() || "Distributed AI",
      autoRefresh,
      notifications: notificationsOn,
      theme: darkMode ? "dark" : "light",
    });
    setShowConfirm(true);
    setTimeout(() => setShowConfirm(false), 2500);
  }

  function handleReset() {
    if (!window.confirm("Reset all settings to defaults?")) return;
    onReset();
  }

  return (
    <div className="card">

      <h2>System Settings</h2>

      <div className="setting">
        <div>
          <strong>Platform Name</strong>
          <p>Name displayed on dashboard</p>
        </div>
        <input
          type="text"
          value={platformName}
          onChange={(e) => setPlatformName(e.target.value)}
        />
      </div>

      <div className="setting">
        <div>
          <strong>Auto Refresh</strong>
          <p>Automatically refresh worker metrics every 5s</p>
        </div>
        <input
          type="checkbox"
          checked={autoRefresh}
          onChange={(e) => setAutoRefresh(e.target.checked)}
        />
      </div>

      <div className="setting">
        <div>
          <strong>Notifications</strong>
          <p>Receive training notifications</p>
        </div>
        <input
          type="checkbox"
          checked={notificationsOn}
          onChange={(e) => setNotificationsOn(e.target.checked)}
        />
      </div>

      <div className="setting">
        <div>
          <strong>Dark Mode</strong>
          <p>Switch to a dark color theme</p>
        </div>
        <input
          type="checkbox"
          checked={darkMode}
          onChange={(e) => setDarkMode(e.target.checked)}
        />
      </div>

      <div className="form-buttons">
        <button className="primary-button" onClick={handleSave}>Save Settings</button>
        <button className="cancel-button" onClick={handleReset}>Reset to Defaults</button>
      </div>

      {showConfirm && <p className="settings-confirm">✓ Settings saved</p>}

    </div>
  );
}


// =====================================================
// HELP
// =====================================================

function Help({ onClearData }) {
  return (
    <div className="card help-card">

      <h2>Distributed AI Training Platform</h2>

      <p>
        This platform is a dashboard for monitoring distributed machine
        learning and large-scale AI model training.
      </p>

      <p>
        Multiple worker machines can participate in model training while the
        dashboard displays worker status, training progress, accuracy, loss
        and system resources.
      </p>

      <p>
        This React application uses simulated training data stored locally in
        your browser via localStorage. All jobs, workers, settings and
        notifications persist across page reloads.
      </p>

      <button className="cancel-button" onClick={onClearData} style={{ marginTop: 20 }}>
        Clear all local data
      </button>

    </div>
  );
}


export default App;
