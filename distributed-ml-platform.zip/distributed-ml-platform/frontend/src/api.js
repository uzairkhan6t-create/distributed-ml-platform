// =====================================================
// API CLIENT
// Every page in the dashboard reads through this file.
// The backend speaks clean REST; the adapters at the
// bottom reshape responses into the props the existing
// components already expect.
// =====================================================

const API_BASE = import.meta.env.VITE_API_BASE || "/api/v1";
const WS_BASE = import.meta.env.VITE_WS_BASE || "";

const TOKEN_KEY = "dai_token";

// Demo credentials seeded by the backend on first run.
const DEMO_EMAIL = import.meta.env.VITE_DEMO_EMAIL || "admin@dmlp.local";
const DEMO_PASSWORD = import.meta.env.VITE_DEMO_PASSWORD || "admin12345";

export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token) {
  if (token) localStorage.setItem(TOKEN_KEY, token);
  else localStorage.removeItem(TOKEN_KEY);
}

class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

async function request(path, { method = "GET", body, retry = true } = {}) {
  const headers = { Accept: "application/json" };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body !== undefined) headers["Content-Type"] = "application/json";

  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  });

  if (res.status === 401 && retry) {
    await login(DEMO_EMAIL, DEMO_PASSWORD);
    return request(path, { method, body, retry: false });
  }

  if (res.status === 204) return null;

  const text = await res.text();
  const payload = text ? JSON.parse(text) : null;

  if (!res.ok) {
    const detail = payload?.detail;
    const message =
      typeof detail === "string"
        ? detail
        : Array.isArray(detail)
        ? detail.map((d) => d.msg).join(", ")
        : `Request failed with status ${res.status}`;
    throw new ApiError(message, res.status);
  }

  return payload;
}

// =====================================================
// AUTH
// =====================================================

export async function login(email = DEMO_EMAIL, password = DEMO_PASSWORD) {
  const res = await fetch(`${API_BASE}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });
  if (!res.ok) throw new ApiError("Sign in failed. Check the backend is running.", res.status);
  const data = await res.json();
  setToken(data.access_token);
  return data.user;
}

export async function ensureSession() {
  if (!getToken()) return login();
  try {
    return await request("/auth/me");
  } catch {
    return login();
  }
}

// =====================================================
// ENDPOINTS
// =====================================================

export const api = {
  summary: () => request("/cluster/summary"),

  nodes: () => request("/nodes"),
  drainNode: (id) => request(`/nodes/${id}/drain`, { method: "POST" }),
  activateNode: (id) => request(`/nodes/${id}/activate`, { method: "POST" }),

  datasets: () => request("/datasets"),
  createSyntheticDataset: (payload) =>
    request("/datasets/synthetic", { method: "POST", body: payload }),

  models: () => request("/models"),

  jobs: () => request("/jobs"),
  job: (id) => request(`/jobs/${id}`),
  createJob: (payload) => request("/jobs", { method: "POST", body: payload }),
  cancelJob: (id) => request(`/jobs/${id}/cancel`, { method: "POST" }),
  deleteJob: (id) => request(`/jobs/${id}`, { method: "DELETE" }),
  jobMetrics: (id) => request(`/jobs/${id}/metrics`),
  jobTasks: (id) => request(`/jobs/${id}/tasks`),

  logs: (search = "") =>
    request(`/logs?limit=300${search ? `&search=${encodeURIComponent(search)}` : ""}`),
};

// =====================================================
// LIVE EVENT STREAM
// =====================================================

export function openClusterStream(onEvent) {
  const proto = window.location.protocol === "https:" ? "wss" : "ws";
  const host = WS_BASE || `${proto}://${window.location.host}`;
  let socket;
  let closed = false;
  let retryDelay = 1000;
  let keepAlive;

  function connect() {
    if (closed) return;
    try {
      socket = new WebSocket(`${host}/ws/cluster`);
    } catch {
      return;
    }

    socket.onopen = () => {
      retryDelay = 1000;
      keepAlive = setInterval(() => {
        if (socket.readyState === WebSocket.OPEN) socket.send("ping");
      }, 20000);
    };

    socket.onmessage = (event) => {
      try {
        onEvent(JSON.parse(event.data));
      } catch {
        /* ignore malformed frames */
      }
    };

    socket.onclose = () => {
      clearInterval(keepAlive);
      if (closed) return;
      setTimeout(connect, retryDelay);
      retryDelay = Math.min(retryDelay * 2, 15000);
    };

    socket.onerror = () => socket.close();
  }

  connect();

  return () => {
    closed = true;
    clearInterval(keepAlive);
    socket?.close();
  };
}

// =====================================================
// ADAPTERS — backend resource -> existing UI shape
// =====================================================

const STATUS_LABEL = {
  queued: "Queued",
  running: "Running",
  completed: "Completed",
  cancelled: "Cancelled",
  failed: "Failed",
};

export function adaptJob(job) {
  return {
    id: `JOB-${String(job.id).padStart(3, "0")}`,
    rawId: job.id,
    model: job.model_name || job.architecture,
    dataset: job.dataset_name,
    workers: job.world_size,
    progress: Math.round(job.progress),
    accuracy: `${(job.best_val_accuracy * 100).toFixed(1)}%`,
    status: STATUS_LABEL[job.status] || job.status,
    epoch: job.current_epoch,
    epochs: job.epochs,
    loss: job.last_val_loss,
    params: job.param_count,
    error: job.error,
  };
}

export function adaptNode(node) {
  const caps = node.capabilities || {};
  const online = node.status !== "offline";
  return {
    id: node.id,
    name: node.name,
    gpu: node.device === "cpu" ? `${node.cpu_cores}-core CPU` : node.device.toUpperCase(),
    cpu: Math.round(caps.cpu_percent || 0),
    gpuUsage: Math.round(caps.gpu_percent || 0),
    memory: Math.round(caps.memory_percent || 0),
    status: online ? "Online" : "Offline",
    state: node.status,
    job: node.status === "busy" ? "Training" : "None",
    tasksCompleted: node.tasks_completed,
    samples: node.samples_processed,
    host: node.hostname || node.ip_address,
  };
}

export function adaptLog(entry) {
  const type =
    entry.level === "error" ? "warning" : entry.level === "warning" ? "warning" : entry.level === "success" ? "success" : "normal";
  return {
    id: entry.id,
    time: new Date(entry.created_at + "Z").toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    }),
    text: entry.message,
    type,
  };
}
