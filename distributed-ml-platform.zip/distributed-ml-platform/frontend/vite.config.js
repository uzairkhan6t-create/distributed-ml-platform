import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// The dashboard talks to the coordinator through a relative /api path, so the
// same build works in dev (proxied below) and in production (served behind any
// reverse proxy). Set VITE_API_BASE to a full URL to bypass the proxy.
const BACKEND = process.env.VITE_BACKEND_URL || "http://127.0.0.1:8000";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    open: true,
    proxy: {
      "/api": { target: BACKEND, changeOrigin: true },
      "/ws": { target: BACKEND, ws: true, changeOrigin: true },
    },
  },
});
