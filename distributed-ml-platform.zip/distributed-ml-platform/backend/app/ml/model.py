"""A small, dependency-free neural network in NumPy.

The same class runs on the coordinator (to hold and update global weights, and to
evaluate on the validation split) and on every worker node (to compute gradients on
its shard). Weights and gradients travel over the REST API as base64-encoded float32
so a worker on another machine can join without sharing a filesystem.
"""

from __future__ import annotations

import base64

import numpy as np


def softmax(z: np.ndarray) -> np.ndarray:
    z = z - z.max(axis=1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=1, keepdims=True)


def encode_vector(vec: np.ndarray) -> str:
    return base64.b64encode(np.asarray(vec, dtype=np.float32).tobytes()).decode("ascii")


def decode_vector(blob: str) -> np.ndarray:
    return np.frombuffer(base64.b64decode(blob), dtype=np.float32).astype(np.float64)


def build_layer_sizes(n_features: int, n_classes: int, architecture: str, hidden: list[int]):
    if architecture == "logreg":
        return [n_features, n_classes]
    return [n_features, *(hidden or [64]), n_classes]


class NeuralNet:
    """Fully connected net with ReLU hidden layers and a softmax output."""

    def __init__(self, layer_sizes: list[int], seed: int = 42):
        self.layer_sizes = list(layer_sizes)
        rng = np.random.default_rng(seed)
        self.weights, self.biases = [], []
        for fan_in, fan_out in zip(self.layer_sizes[:-1], self.layer_sizes[1:]):
            # He initialisation keeps ReLU activations from collapsing in deeper nets.
            self.weights.append(rng.normal(0.0, np.sqrt(2.0 / fan_in), (fan_in, fan_out)))
            self.biases.append(np.zeros(fan_out))

    # --- flat vector view (what we send over the wire) --------------------
    @property
    def n_params(self) -> int:
        return sum(w.size + b.size for w, b in zip(self.weights, self.biases))

    def get_flat(self) -> np.ndarray:
        return np.concatenate([p.ravel() for pair in zip(self.weights, self.biases) for p in pair])

    def set_flat(self, flat: np.ndarray) -> None:
        offset = 0
        for i, (w, b) in enumerate(zip(self.weights, self.biases)):
            self.weights[i] = flat[offset : offset + w.size].reshape(w.shape).copy()
            offset += w.size
            self.biases[i] = flat[offset : offset + b.size].reshape(b.shape).copy()
            offset += b.size

    # --- forward / backward ----------------------------------------------
    def forward(self, X: np.ndarray):
        activations = [X]
        pre = []
        a = X
        for i, (w, b) in enumerate(zip(self.weights, self.biases)):
            z = a @ w + b
            pre.append(z)
            a = softmax(z) if i == len(self.weights) - 1 else np.maximum(z, 0.0)
            activations.append(a)
        return activations, pre

    def loss_and_grad(self, X: np.ndarray, y: np.ndarray, l2: float = 0.0):
        """Cross-entropy loss + gradient of every parameter, returned as a flat vector."""
        n = X.shape[0]
        activations, _ = self.forward(X)
        probs = activations[-1]

        eps = 1e-12
        loss = -np.log(probs[np.arange(n), y] + eps).mean()
        if l2:
            loss += 0.5 * l2 * sum((w**2).sum() for w in self.weights)

        delta = probs.copy()
        delta[np.arange(n), y] -= 1.0
        delta /= n

        grads_w = [None] * len(self.weights)
        grads_b = [None] * len(self.biases)
        for i in range(len(self.weights) - 1, -1, -1):
            grads_w[i] = activations[i].T @ delta + l2 * self.weights[i]
            grads_b[i] = delta.sum(axis=0)
            if i > 0:
                delta = (delta @ self.weights[i].T) * (activations[i] > 0)

        flat_grad = np.concatenate(
            [g.ravel() for pair in zip(grads_w, grads_b) for g in pair]
        )
        accuracy = float((probs.argmax(axis=1) == y).mean())
        return float(loss), flat_grad, accuracy

    def evaluate(self, X: np.ndarray, y: np.ndarray):
        activations, _ = self.forward(X)
        probs = activations[-1]
        loss = float(-np.log(probs[np.arange(len(y)), y] + 1e-12).mean())
        acc = float((probs.argmax(axis=1) == y).mean())
        return loss, acc

    def predict(self, X: np.ndarray):
        activations, _ = self.forward(X)
        probs = activations[-1]
        return probs.argmax(axis=1), probs

    # --- persistence ------------------------------------------------------
    def save(self, path) -> None:
        np.savez_compressed(path, flat=self.get_flat(), sizes=np.array(self.layer_sizes))

    @classmethod
    def load(cls, path) -> "NeuralNet":
        data = np.load(path)
        net = cls([int(s) for s in data["sizes"]])
        net.set_flat(data["flat"])
        return net


def local_update(
    flat_weights: np.ndarray,
    layer_sizes: list[int],
    X: np.ndarray,
    y: np.ndarray,
    batch_size: int,
    local_steps: int,
    l2: float,
    seed: int = 0,
):
    """Worker side: run `local_steps` mini-batches and return the averaged gradient.

    This is synchronous data-parallel SGD — every worker starts the round from the
    same global weights, so the gradients can be safely averaged by the coordinator.
    """
    net = NeuralNet(layer_sizes)
    net.set_flat(flat_weights)

    rng = np.random.default_rng(seed)
    n = X.shape[0]
    batch_size = max(1, min(batch_size, n))

    total_grad = np.zeros(net.n_params)
    total_loss = 0.0
    total_acc = 0.0
    seen = 0

    for _ in range(max(1, local_steps)):
        idx = rng.choice(n, size=batch_size, replace=False) if batch_size < n else np.arange(n)
        loss, grad, acc = net.loss_and_grad(X[idx], y[idx], l2=l2)
        total_grad += grad
        total_loss += loss
        total_acc += acc
        seen += len(idx)

    steps = max(1, local_steps)
    return total_grad / steps, total_loss / steps, total_acc / steps, seen
