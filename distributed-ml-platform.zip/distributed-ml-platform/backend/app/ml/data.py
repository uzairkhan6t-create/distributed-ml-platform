"""Dataset creation, on-disk storage and shard extraction.

Datasets live in storage/datasets/<id>/ as train.npz + val.npz. Workers never read
this folder directly — they pull their shard over HTTP, which is what makes the
platform work across machines.
"""

from __future__ import annotations

import csv
import io
from pathlib import Path

import numpy as np

from ..config import DATASET_DIR


def dataset_path(dataset_id: int) -> Path:
    p = DATASET_DIR / str(dataset_id)
    p.mkdir(parents=True, exist_ok=True)
    return p


def make_synthetic(
    n_samples: int,
    n_features: int,
    n_classes: int,
    class_sep: float = 2.0,
    noise: float = 1.0,
    seed: int = 7,
):
    """Gaussian clusters with a random linear mixing — separable but not trivially so."""
    rng = np.random.default_rng(seed)
    centers = rng.normal(0, class_sep, size=(n_classes, n_features))
    y = rng.integers(0, n_classes, size=n_samples)
    X = centers[y] + rng.normal(0, noise, size=(n_samples, n_features))
    mixing = rng.normal(0, 1, size=(n_features, n_features)) / np.sqrt(n_features)
    X = X @ mixing
    X = (X - X.mean(axis=0)) / (X.std(axis=0) + 1e-8)
    return X.astype(np.float32), y.astype(np.int64)


def parse_csv(raw: bytes, label_column: str | int | None = None):
    """Last column is the label unless a column name/index is given."""
    text = raw.decode("utf-8-sig", errors="replace")
    reader = csv.reader(io.StringIO(text))
    rows = [r for r in reader if r]
    if not rows:
        raise ValueError("The CSV file is empty.")

    header = rows[0]
    has_header = any(not _is_number(c) for c in header)
    body = rows[1:] if has_header else rows
    if not body:
        raise ValueError("The CSV has a header but no data rows.")

    if label_column is None:
        label_idx = len(header) - 1
    elif isinstance(label_column, int):
        label_idx = label_column
    else:
        if not has_header or label_column not in header:
            raise ValueError(f"Column '{label_column}' is not in the CSV header.")
        label_idx = header.index(label_column)

    features, labels = [], []
    for r in body:
        if len(r) != len(header):
            continue
        try:
            feats = [float(v) for i, v in enumerate(r) if i != label_idx]
        except ValueError:
            continue
        features.append(feats)
        labels.append(r[label_idx].strip())

    if not features:
        raise ValueError("No numeric rows could be read from the CSV.")

    X = np.asarray(features, dtype=np.float32)
    classes = sorted(set(labels))
    mapping = {c: i for i, c in enumerate(classes)}
    y = np.asarray([mapping[v] for v in labels], dtype=np.int64)
    X = (X - X.mean(axis=0)) / (X.std(axis=0) + 1e-8)
    return X, y, classes


def _is_number(value: str) -> bool:
    try:
        float(value)
        return True
    except ValueError:
        return False


def persist(dataset_id: int, X: np.ndarray, y: np.ndarray, val_split: float, seed: int = 7):
    """Shuffle, split into train/val and write both halves to disk."""
    rng = np.random.default_rng(seed)
    order = rng.permutation(len(y))
    X, y = X[order], y[order]

    n_val = max(1, int(len(y) * val_split)) if val_split > 0 else 0
    X_val, y_val = X[:n_val], y[:n_val]
    X_train, y_train = X[n_val:], y[n_val:]

    path = dataset_path(dataset_id)
    np.savez_compressed(path / "train.npz", X=X_train, y=y_train)
    np.savez_compressed(path / "val.npz", X=X_val, y=y_val)

    size = sum(f.stat().st_size for f in path.glob("*.npz"))
    return len(y_train), len(y_val), size


def load_split(dataset_id: int, split: str = "train"):
    data = np.load(dataset_path(dataset_id) / f"{split}.npz")
    return data["X"].astype(np.float64), data["y"].astype(np.int64)


def shard_bounds(n_samples: int, world_size: int, shard_index: int) -> tuple[int, int]:
    """Contiguous, near-equal ranges; leftover rows go to the earliest shards."""
    base, extra = divmod(n_samples, world_size)
    start = shard_index * base + min(shard_index, extra)
    end = start + base + (1 if shard_index < extra else 0)
    return start, end


def shard_bytes(dataset_id: int, world_size: int, shard_index: int) -> bytes:
    """Serialise one shard as an .npz payload for HTTP transfer."""
    X, y = load_split(dataset_id, "train")
    start, end = shard_bounds(len(y), world_size, shard_index)
    buf = io.BytesIO()
    np.savez_compressed(buf, X=X[start:end].astype(np.float32), y=y[start:end])
    return buf.getvalue()
