"""Database models for the Distributed ML Platform."""

from datetime import datetime, timezone

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base


def utcnow() -> datetime:
    """Naive UTC — the DateTime columns are timezone-less, so everything stored
    and everything compared in Python stays on the same footing."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(120), default="")
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(20), default="engineer")  # admin | engineer
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Node(Base):
    """A worker machine that has joined the cluster."""

    __tablename__ = "nodes"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    hostname: Mapped[str] = mapped_column(String(255), default="")
    ip_address: Mapped[str] = mapped_column(String(64), default="")
    device: Mapped[str] = mapped_column(String(32), default="cpu")      # cpu | cuda:0 ...
    cpu_cores: Mapped[int] = mapped_column(Integer, default=1)
    memory_gb: Mapped[float] = mapped_column(Float, default=1.0)
    status: Mapped[str] = mapped_column(String(20), default="idle")     # idle|busy|offline|draining
    capabilities: Mapped[dict] = mapped_column(JSON, default=dict)
    tasks_completed: Mapped[int] = mapped_column(Integer, default=0)
    tasks_failed: Mapped[int] = mapped_column(Integer, default=0)
    samples_processed: Mapped[int] = mapped_column(Integer, default=0)
    last_heartbeat: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    registered_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    tasks: Mapped[list["Task"]] = relationship(back_populates="node")


class Dataset(Base):
    __tablename__ = "datasets"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    description: Mapped[str] = mapped_column(Text, default="")
    source: Mapped[str] = mapped_column(String(20), default="synthetic")  # synthetic | csv
    n_samples: Mapped[int] = mapped_column(Integer, default=0)
    n_features: Mapped[int] = mapped_column(Integer, default=0)
    n_classes: Mapped[int] = mapped_column(Integer, default=0)
    val_split: Mapped[float] = mapped_column(Float, default=0.2)
    size_bytes: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    jobs: Mapped[list["Job"]] = relationship(back_populates="dataset")


class Job(Base):
    """One distributed training run."""

    __tablename__ = "jobs"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    dataset_id: Mapped[int] = mapped_column(ForeignKey("datasets.id"))
    owner_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)

    architecture: Mapped[str] = mapped_column(String(40), default="mlp")  # mlp | logreg
    hidden_layers: Mapped[list] = mapped_column(JSON, default=list)
    epochs: Mapped[int] = mapped_column(Integer, default=10)
    batch_size: Mapped[int] = mapped_column(Integer, default=64)
    learning_rate: Mapped[float] = mapped_column(Float, default=0.05)
    momentum: Mapped[float] = mapped_column(Float, default=0.9)
    l2: Mapped[float] = mapped_column(Float, default=1e-4)
    world_size: Mapped[int] = mapped_column(Integer, default=2)   # number of shards / workers
    local_steps: Mapped[int] = mapped_column(Integer, default=1)  # mini-batches per worker per round

    status: Mapped[str] = mapped_column(String(20), default="queued", index=True)
    # queued | running | completed | failed | cancelled
    current_epoch: Mapped[int] = mapped_column(Integer, default=0)
    best_val_accuracy: Mapped[float] = mapped_column(Float, default=0.0)
    last_train_loss: Mapped[float] = mapped_column(Float, default=0.0)
    last_val_loss: Mapped[float] = mapped_column(Float, default=0.0)
    error: Mapped[str] = mapped_column(Text, default="")
    param_count: Mapped[int] = mapped_column(Integer, default=0)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    dataset: Mapped["Dataset"] = relationship(back_populates="jobs")
    tasks: Mapped[list["Task"]] = relationship(back_populates="job", cascade="all, delete-orphan")
    metrics: Mapped[list["EpochMetric"]] = relationship(
        back_populates="job", cascade="all, delete-orphan"
    )


class Task(Base):
    """A single shard-epoch unit of work handed to one worker node."""

    __tablename__ = "tasks"
    __table_args__ = (UniqueConstraint("job_id", "epoch", "shard_index", name="uq_task_slot"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    job_id: Mapped[int] = mapped_column(ForeignKey("jobs.id"), index=True)
    node_id: Mapped[int | None] = mapped_column(ForeignKey("nodes.id"), nullable=True)
    epoch: Mapped[int] = mapped_column(Integer)
    shard_index: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(20), default="pending", index=True)
    # pending | assigned | completed | failed
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    loss: Mapped[float] = mapped_column(Float, default=0.0)
    accuracy: Mapped[float] = mapped_column(Float, default=0.0)
    samples: Mapped[int] = mapped_column(Integer, default=0)
    duration_ms: Mapped[float] = mapped_column(Float, default=0.0)
    error: Mapped[str] = mapped_column(Text, default="")
    assigned_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    job: Mapped["Job"] = relationship(back_populates="tasks")
    node: Mapped["Node"] = relationship(back_populates="tasks")


class EpochMetric(Base):
    """Aggregated result of one synchronous round (epoch) across all workers."""

    __tablename__ = "epoch_metrics"
    __table_args__ = (UniqueConstraint("job_id", "epoch", name="uq_metric_slot"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    job_id: Mapped[int] = mapped_column(ForeignKey("jobs.id"), index=True)
    epoch: Mapped[int] = mapped_column(Integer)
    train_loss: Mapped[float] = mapped_column(Float, default=0.0)
    train_accuracy: Mapped[float] = mapped_column(Float, default=0.0)
    val_loss: Mapped[float] = mapped_column(Float, default=0.0)
    val_accuracy: Mapped[float] = mapped_column(Float, default=0.0)
    grad_norm: Mapped[float] = mapped_column(Float, default=0.0)
    samples: Mapped[int] = mapped_column(Integer, default=0)
    wall_time_s: Mapped[float] = mapped_column(Float, default=0.0)
    throughput: Mapped[float] = mapped_column(Float, default=0.0)  # samples/sec
    workers: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    job: Mapped["Job"] = relationship(back_populates="metrics")


class LogEntry(Base):
    __tablename__ = "logs"

    id: Mapped[int] = mapped_column(primary_key=True)
    job_id: Mapped[int | None] = mapped_column(ForeignKey("jobs.id"), nullable=True, index=True)
    level: Mapped[str] = mapped_column(String(12), default="info")
    source: Mapped[str] = mapped_column(String(60), default="coordinator")
    message: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)


class Checkpoint(Base):
    __tablename__ = "checkpoints"

    id: Mapped[int] = mapped_column(primary_key=True)
    job_id: Mapped[int] = mapped_column(ForeignKey("jobs.id"), index=True)
    epoch: Mapped[int] = mapped_column(Integer)
    path: Mapped[str] = mapped_column(String(500))
    val_accuracy: Mapped[float] = mapped_column(Float, default=0.0)
    is_best: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
