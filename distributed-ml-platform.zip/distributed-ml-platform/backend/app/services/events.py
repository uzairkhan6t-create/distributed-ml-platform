"""In-process pub/sub used to push cluster and job events to connected dashboards."""

from __future__ import annotations

import asyncio
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any

from fastapi import WebSocket


class EventHub:
    def __init__(self) -> None:
        self._channels: dict[str, set[WebSocket]] = defaultdict(set)
        self._lock = asyncio.Lock()
        self._loop: asyncio.AbstractEventLoop | None = None

    def bind_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        """Called once at startup so worker threads can schedule broadcasts safely."""
        self._loop = loop

    async def connect(self, channel: str, ws: WebSocket) -> None:
        await ws.accept()
        async with self._lock:
            self._channels[channel].add(ws)

    async def disconnect(self, channel: str, ws: WebSocket) -> None:
        async with self._lock:
            self._channels[channel].discard(ws)

    async def broadcast(self, channel: str, event: str, data: dict[str, Any]) -> None:
        message = {
            "event": event,
            "channel": channel,
            "ts": datetime.now(timezone.utc).isoformat(),
            "data": data,
        }
        async with self._lock:
            targets = list(self._channels.get(channel, ()))
        dead = []
        for ws in targets:
            try:
                await ws.send_json(message)
            except Exception:
                dead.append(ws)
        if dead:
            async with self._lock:
                for ws in dead:
                    self._channels[channel].discard(ws)

    def publish(self, channel: str, event: str, data: dict[str, Any]) -> None:
        """Thread-safe fire-and-forget publish; usable from sync request handlers."""
        if self._loop is None:
            return
        asyncio.run_coroutine_threadsafe(self.broadcast(channel, event, data), self._loop)

    def publish_many(self, channels: list[str], event: str, data: dict[str, Any]) -> None:
        for ch in channels:
            self.publish(ch, event, data)


hub = EventHub()
