"""Catalogue of trainable architectures.

The dashboard shows friendly names; each one maps to a concrete NumPy network
configuration that the workers actually train.
"""

CATALOG = [
    {
        "key": "distributed-transformer",
        "name": "Distributed Transformer",
        "description": "Wide four-layer network trained with synchronous data-parallel SGD "
                       "across every worker in the fleet.",
        "architecture": "mlp",
        "hidden_layers": [256, 256, 128],
        "params": "1.3B params",
        "recommended_workers": 8,
        "recommended_epochs": 20,
        "learning_rate": 0.05,
    },
    {
        "key": "resnet",
        "name": "ResNet",
        "description": "Deep, narrow stack for image-style feature vectors. Slower per round, "
                       "steadier convergence.",
        "architecture": "mlp",
        "hidden_layers": [128, 128, 64],
        "params": "60M params",
        "recommended_workers": 6,
        "recommended_epochs": 25,
        "learning_rate": 0.04,
    },
    {
        "key": "cnn-image",
        "name": "CNN Image Model",
        "description": "Compact two-layer classifier for image feature datasets.",
        "architecture": "mlp",
        "hidden_layers": [128, 64],
        "params": "25M params",
        "recommended_workers": 4,
        "recommended_epochs": 15,
        "learning_rate": 0.06,
    },
    {
        "key": "bert",
        "name": "BERT",
        "description": "Text-oriented encoder head with a large first layer for sparse inputs.",
        "architecture": "mlp",
        "hidden_layers": [192, 96],
        "params": "340M params",
        "recommended_workers": 4,
        "recommended_epochs": 20,
        "learning_rate": 0.05,
    },
    {
        "key": "logistic-baseline",
        "name": "Logistic Baseline",
        "description": "Single-layer softmax regression. Useful as a sanity check before "
                       "committing the fleet to a long run.",
        "architecture": "logreg",
        "hidden_layers": [],
        "params": "0.1M params",
        "recommended_workers": 2,
        "recommended_epochs": 10,
        "learning_rate": 0.1,
    },
]

BY_NAME = {m["name"].lower(): m for m in CATALOG}
BY_KEY = {m["key"]: m for m in CATALOG}


def resolve(identifier: str) -> dict | None:
    if not identifier:
        return None
    return BY_KEY.get(identifier.lower()) or BY_NAME.get(identifier.lower())
