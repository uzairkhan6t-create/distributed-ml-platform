"""Coordinator — the parameter server at the centre of the platform.

Training round (one epoch):
  1. The coordinator creates one task per shard and marks the job `running`.
  2. Each worker node pulls a task, downloads its shard, and computes a gradient
     starting from the *same* global weights.
  3. Workers post their gradients back. When the last one arrives, the coordinator
     averages them (weighted by shard size), applies an SGD-with-momentum step,
     evaluates the new global model on the held-out split, writes a checkpoint,
     and opens the next round.

That is textbook synchronous data-parallel SGD, just with HTTP instead of NCCL.
"""

from __future__ import annotations

import threading
import time
from datetime import timedelta
from pathlib import Path

import numpy as np
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..config import HEARTBEAT_TIMEOUT_S, RUN_DIR, TASK_LEASE_TIMEOUT_S
from ..ml import data as data_utils
from ..ml.model import NeuralNet, build_layer_sizes, decode_vector, encode_vector
from ..models import Checkpoint, EpochMetric, Job, LogEntry, Node, Task, utcnow
from .events import hub

MAX_ATTEMPTS = 3
_job_locks: dict[int, threading.Lock] = {}
_locks_guard = threading.Lock()


def _lock_for(job_id: int) -> threading.Lock:
    with _locks_guard:
        return _job_locks.setdefault(job_id, threading.Lock())


def run_dir(job_id: int) -> Path:
    p = RUN_DIR / str(job_id)
    (p / "grads").mkdir(parents=True, exist_ok=True)
    (p / "checkpoints").mkdir(parents=True, exist_ok=True)
    return p


# --------------------------------------------------------------------------
# logging
# --------------------------------------------------------------------------
def log(db: Session, message: str, level: str = "info", job_id: int | None = None,
        source: str = "coordinator") -> None:
    entry = LogEntry(job_id=job_id, level=level, source=source, message=message)
    db.add(entry)
    db.commit()
    payload = {
        "id": entry.id,
        "job_id": job_id,
        "level": level,
        "source": source,
        "message": message,
        "created_at": entry.created_at.isoformat(),
    }
    channels = ["cluster"] + ([f"job:{job_id}"] if job_id else [])
    hub.publish_many(channels, "log", payload)


# --------------------------------------------------------------------------
# job lifecycle
# --------------------------------------------------------------------------
def layer_sizes_for(job: Job) -> list[int]:
    return build_layer_sizes(
        job.dataset.n_features, job.dataset.n_classes, job.architecture, job.hidden_layers or []
    )


def start_job(db: Session, job: Job) -> Job:
    """Initialise global weights and open round 1."""
    sizes = layer_sizes_for(job)
    net = NeuralNet(sizes, seed=42)

    d = run_dir(job.id)
    np.save(d / "weights.npy", net.get_flat())
    np.save(d / "velocity.npy", np.zeros(net.n_params))

    job.status = "running"
    job.current_epoch = 1
    job.started_at = utcnow()
    job.param_count = net.n_params
    job.error = ""
    db.commit()

    _create_round_tasks(db, job, epoch=1)
    log(db, f"Job {job.id} started — {job.world_size} shards, {net.n_params:,} parameters",
        "success", job.id)
    _publish_job(db, job, "job_started")
    return job


def _create_round_tasks(db: Session, job: Job, epoch: int) -> None:
    for shard in range(job.world_size):
        exists = db.scalar(
            select(Task).where(Task.job_id == job.id, Task.epoch == epoch, Task.shard_index == shard)
        )
        if exists is None:
            db.add(Task(job_id=job.id, epoch=epoch, shard_index=shard, status="pending"))
    db.commit()
    hub.publish("cluster", "round_opened", {"job_id": job.id, "epoch": epoch,
                                            "shards": job.world_size})


def cancel_job(db: Session, job: Job) -> Job:
    job.status = "cancelled"
    job.finished_at = utcnow()
    db.commit()
    db.query(Task).filter(Task.job_id == job.id, Task.status.in_(["pending", "assigned"])).update(
        {"status": "failed", "error": "job cancelled"}, synchronize_session=False
    )
    db.commit()
    _release_nodes(db, job.id)
    log(db, f"Job {job.id} cancelled by user", "warning", job.id)
    _publish_job(db, job, "job_cancelled")
    return job


def _release_nodes(db: Session, job_id: int) -> None:
    node_ids = [
        r[0]
        for r in db.execute(
            select(Task.node_id).where(Task.job_id == job_id, Task.node_id.isnot(None)).distinct()
        )
    ]
    if node_ids:
        db.query(Node).filter(Node.id.in_(node_ids), Node.status == "busy").update(
            {"status": "idle"}, synchronize_session=False
        )
        db.commit()


# --------------------------------------------------------------------------
# task dispatch (worker pull model)
# --------------------------------------------------------------------------
def claim_task(db: Session, node: Node) -> Task | None:
    """Hand the oldest pending task of the oldest running job to this node."""
    with _locks_guard:
        pass  # claiming is serialised per-job below

    task = db.scalar(
        select(Task)
        .join(Job, Job.id == Task.job_id)
        .where(Task.status == "pending", Job.status == "running")
        .order_by(Job.created_at, Task.epoch, Task.shard_index)
        .limit(1)
    )
    if task is None:
        return None

    with _lock_for(task.job_id):
        db.refresh(task)
        if task.status != "pending":
            return None
        task.status = "assigned"
        task.node_id = node.id
        task.attempts += 1
        task.assigned_at = utcnow()
        node.status = "busy"
        db.commit()

    hub.publish_many(
        ["cluster", f"job:{task.job_id}"],
        "task_assigned",
        {"task_id": task.id, "job_id": task.job_id, "epoch": task.epoch,
         "shard_index": task.shard_index, "node": node.name},
    )
    return task


def task_payload(db: Session, task: Task) -> dict:
    """Everything a worker needs to do one round of local training."""
    job = db.get(Job, task.job_id)
    weights = np.load(run_dir(job.id) / "weights.npy")
    n_train = job.dataset.n_samples
    start, end = data_utils.shard_bounds(n_train, job.world_size, task.shard_index)

    return {
        "task_id": task.id,
        "job_id": job.id,
        "job_name": job.name,
        "epoch": task.epoch,
        "shard_index": task.shard_index,
        "world_size": job.world_size,
        "dataset_id": job.dataset_id,
        "shard_samples": end - start,
        "layer_sizes": layer_sizes_for(job),
        "batch_size": job.batch_size,
        "local_steps": job.local_steps,
        "l2": job.l2,
        "weights": encode_vector(weights),
    }


def submit_result(
    db: Session,
    task: Task,
    gradients: str,
    loss: float,
    accuracy: float,
    samples: int,
    duration_ms: float,
) -> dict:
    """Store one worker's gradient; aggregate the round if it was the last one."""
    job = db.get(Job, task.job_id)
    if job.status != "running":
        return {"status": "ignored", "reason": f"job is {job.status}"}

    grad = decode_vector(gradients)
    np.save(run_dir(job.id) / "grads" / f"e{task.epoch}_s{task.shard_index}.npy", grad)

    task.status = "completed"
    task.loss = float(loss)
    task.accuracy = float(accuracy)
    task.samples = int(samples)
    task.duration_ms = float(duration_ms)
    task.completed_at = utcnow()

    if task.node_id:
        node = db.get(Node, task.node_id)
        if node:
            node.tasks_completed += 1
            node.samples_processed += int(samples)
            node.status = "idle"
    db.commit()

    hub.publish_many(
        ["cluster", f"job:{job.id}"],
        "task_completed",
        {"task_id": task.id, "job_id": job.id, "epoch": task.epoch,
         "shard_index": task.shard_index, "loss": round(float(loss), 4),
         "accuracy": round(float(accuracy), 4)},
    )

    with _lock_for(job.id):
        remaining = db.scalar(
            select(func.count(Task.id)).where(
                Task.job_id == job.id, Task.epoch == task.epoch,
                Task.status.in_(["pending", "assigned"])
            )
        )
        if remaining == 0:
            _aggregate_round(db, job, task.epoch)

    return {"status": "accepted", "task_id": task.id}


def fail_task(db: Session, task: Task, error: str) -> None:
    task.error = error[:500]
    if task.attempts >= MAX_ATTEMPTS:
        task.status = "failed"
    else:
        task.status = "pending"      # another node will pick it up
        task.node_id = None
        task.assigned_at = None
    if task.node_id:
        node = db.get(Node, task.node_id)
        if node:
            node.tasks_failed += 1
            node.status = "idle"
    db.commit()
    log(db, f"Task {task.id} failed (attempt {task.attempts}): {error[:120]}",
        "error", task.job_id)

    if task.status == "failed":
        job = db.get(Job, task.job_id)
        job.status = "failed"
        job.error = f"Shard {task.shard_index} failed after {MAX_ATTEMPTS} attempts."
        job.finished_at = utcnow()
        db.commit()
        _publish_job(db, job, "job_failed")


# --------------------------------------------------------------------------
# aggregation
# --------------------------------------------------------------------------
def _aggregate_round(db: Session, job: Job, epoch: int) -> None:
    started = time.time()
    d = run_dir(job.id)
    tasks = list(db.scalars(select(Task).where(Task.job_id == job.id, Task.epoch == epoch)))
    done = [t for t in tasks if t.status == "completed"]
    if not done:
        return

    weights = np.load(d / "weights.npy")
    velocity = np.load(d / "velocity.npy")

    total_samples = sum(t.samples for t in done) or 1
    agg_grad = np.zeros_like(weights)
    train_loss = 0.0
    train_acc = 0.0

    for t in done:
        grad = np.load(d / "grads" / f"e{epoch}_s{t.shard_index}.npy")
        w = t.samples / total_samples
        agg_grad += w * grad
        train_loss += w * t.loss
        train_acc += w * t.accuracy

    # SGD with Nesterov-free classical momentum
    velocity = job.momentum * velocity - job.learning_rate * agg_grad
    weights = weights + velocity

    np.save(d / "weights.npy", weights)
    np.save(d / "velocity.npy", velocity)

    # --- evaluate the freshly averaged global model ----------------------
    sizes = layer_sizes_for(job)
    net = NeuralNet(sizes)
    net.set_flat(weights)
    try:
        X_val, y_val = data_utils.load_split(job.dataset_id, "val")
        val_loss, val_acc = net.evaluate(X_val, y_val) if len(y_val) else (0.0, 0.0)
    except FileNotFoundError:
        val_loss, val_acc = 0.0, 0.0

    wall = time.time() - started
    epoch_wall = _epoch_wall_time(done)
    metric = EpochMetric(
        job_id=job.id,
        epoch=epoch,
        train_loss=float(train_loss),
        train_accuracy=float(train_acc),
        val_loss=float(val_loss),
        val_accuracy=float(val_acc),
        grad_norm=float(np.linalg.norm(agg_grad)),
        samples=int(total_samples),
        wall_time_s=float(epoch_wall + wall),
        throughput=float(total_samples / max(epoch_wall, 1e-6)),
        workers=len(done),
    )
    db.add(metric)

    job.last_train_loss = float(train_loss)
    job.last_val_loss = float(val_loss)
    is_best = val_acc >= job.best_val_accuracy
    if is_best:
        job.best_val_accuracy = float(val_acc)

    ckpt_path = d / "checkpoints" / f"epoch_{epoch}.npz"
    net.save(ckpt_path)
    db.add(Checkpoint(job_id=job.id, epoch=epoch, path=str(ckpt_path),
                      val_accuracy=float(val_acc), is_best=bool(is_best)))
    db.commit()

    hub.publish_many(
        ["cluster", f"job:{job.id}"],
        "epoch_completed",
        {"job_id": job.id, "epoch": epoch,
         "train_loss": round(float(train_loss), 4),
         "train_accuracy": round(float(train_acc), 4),
         "val_loss": round(float(val_loss), 4),
         "val_accuracy": round(float(val_acc), 4),
         "throughput": round(metric.throughput, 1),
         "progress": round(100 * epoch / max(job.epochs, 1), 1)},
    )
    log(db, f"Epoch {epoch}/{job.epochs} — val accuracy {val_acc * 100:.2f}%, "
            f"loss {val_loss:.4f}", "info", job.id)

    # --- next round or finish -------------------------------------------
    if epoch >= job.epochs:
        job.status = "completed"
        job.current_epoch = epoch
        job.finished_at = utcnow()
        db.commit()
        _release_nodes(db, job.id)
        log(db, f"Job {job.id} completed — best accuracy {job.best_val_accuracy * 100:.2f}%",
            "success", job.id)
        _publish_job(db, job, "job_completed")
    else:
        job.current_epoch = epoch + 1
        db.commit()
        _create_round_tasks(db, job, epoch + 1)
        _publish_job(db, job, "job_progress")


def _epoch_wall_time(tasks: list[Task]) -> float:
    """Real elapsed time for the round: first hand-out to last gradient received.

    With fewer nodes than shards a single worker runs several shards back to back,
    so this span — not the slowest single task — is the honest round time.
    """
    strip = lambda d: d.replace(tzinfo=None) if d.tzinfo else d
    starts = [strip(t.assigned_at) for t in tasks if t.assigned_at]
    ends = [strip(t.completed_at) for t in tasks if t.completed_at]
    if starts and ends:
        span = (max(ends) - min(starts)).total_seconds()
        if span > 0:
            return span
    times = [t.duration_ms / 1000.0 for t in tasks if t.duration_ms]
    return sum(times) if times else 0.0


# --------------------------------------------------------------------------
# health reaper
# --------------------------------------------------------------------------
def reap(db: Session) -> None:
    """Mark silent nodes offline and requeue any work they were holding."""
    now = utcnow()
    dead_line = now - timedelta(seconds=HEARTBEAT_TIMEOUT_S)

    stale_nodes = list(
        db.scalars(
            select(Node).where(Node.last_heartbeat < dead_line, Node.status != "offline")
        )
    )
    for node in stale_nodes:
        node.status = "offline"
        log(db, f"{node.name} stopped sending heartbeats and was marked offline",
            "warning", source="health")
    if stale_nodes:
        db.commit()
        hub.publish("cluster", "nodes_changed", {"offline": [n.name for n in stale_nodes]})

    lease_line = now - timedelta(seconds=TASK_LEASE_TIMEOUT_S)
    orphans = list(
        db.scalars(select(Task).where(Task.status == "assigned", Task.assigned_at < lease_line))
    )
    for task in orphans:
        task.status = "pending"
        task.node_id = None
        task.assigned_at = None
        log(db, f"Task {task.id} (job {task.job_id}, shard {task.shard_index}) "
                f"timed out and was requeued", "warning", task.job_id, source="health")
    if orphans:
        db.commit()


def _publish_job(db: Session, job: Job, event: str) -> None:
    hub.publish_many(
        ["cluster", f"job:{job.id}"],
        event,
        {
            "job_id": job.id,
            "name": job.name,
            "status": job.status,
            "epoch": job.current_epoch,
            "epochs": job.epochs,
            "progress": round(100 * job.current_epoch / max(job.epochs, 1), 1)
            if job.status != "completed" else 100.0,
            "best_val_accuracy": job.best_val_accuracy,
        },
    )
