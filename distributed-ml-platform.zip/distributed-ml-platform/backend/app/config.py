"""Central configuration. Everything can be overridden with environment variables."""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]          # project root
STORAGE_DIR = Path(os.getenv("DMLP_STORAGE", BASE_DIR / "storage"))
DATASET_DIR = STORAGE_DIR / "datasets"
RUN_DIR = STORAGE_DIR / "runs"

for _d in (STORAGE_DIR, DATASET_DIR, RUN_DIR):
    _d.mkdir(parents=True, exist_ok=True)

DATABASE_URL = os.getenv("DMLP_DATABASE_URL", f"sqlite:///{STORAGE_DIR / 'dmlp.db'}")

# --- security -------------------------------------------------------------
JWT_SECRET = os.getenv("DMLP_JWT_SECRET", "change-me-in-production-please")
JWT_ALGORITHM = "HS256"
JWT_TTL_MINUTES = int(os.getenv("DMLP_JWT_TTL", "720"))

# Shared secret that worker agents present when they join the cluster.
CLUSTER_TOKEN = os.getenv("DMLP_CLUSTER_TOKEN", "dev-cluster-token")

# --- cluster behaviour ----------------------------------------------------
HEARTBEAT_TIMEOUT_S = int(os.getenv("DMLP_HEARTBEAT_TIMEOUT", "25"))
TASK_LEASE_TIMEOUT_S = int(os.getenv("DMLP_TASK_LEASE_TIMEOUT", "120"))
REAPER_INTERVAL_S = 5

API_PREFIX = "/api/v1"
APP_NAME = "Distributed ML Platform"
APP_VERSION = "1.0.0"
