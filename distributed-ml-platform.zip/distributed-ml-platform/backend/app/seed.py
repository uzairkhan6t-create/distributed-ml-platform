"""First-run seeding: one admin account and one ready-to-train dataset."""

from sqlalchemy import select
from sqlalchemy.orm import Session

from .ml import data as data_utils
from .models import Dataset, User
from .security import hash_password

DEMO_EMAIL = "admin@dmlp.local"
DEMO_PASSWORD = "admin12345"


def ensure_seed(db: Session) -> None:
    if db.scalar(select(User).limit(1)) is None:
        db.add(
            User(
                email=DEMO_EMAIL,
                full_name="Platform Admin",
                password_hash=hash_password(DEMO_PASSWORD),
                role="admin",
            )
        )
        db.commit()
        print(f"[seed] created admin account {DEMO_EMAIL} / {DEMO_PASSWORD}")

    if db.scalar(select(Dataset).limit(1)) is None:
        ds = Dataset(
            name="Large AI Dataset",
            description="Synthetic 150k-row, 64-feature, 8-class benchmark generated on first run.",
            source="synthetic",
            n_features=64,
            n_classes=8,
            val_split=0.2,
        )
        db.add(ds)
        db.commit()
        db.refresh(ds)

        X, y = data_utils.make_synthetic(150_000, 64, 8, class_sep=1.1, noise=1.3, seed=7)
        n_train, _, size = data_utils.persist(ds.id, X, y, 0.2)
        ds.n_samples = n_train
        ds.size_bytes = size
        db.commit()
        print(f"[seed] generated dataset '{ds.name}' ({n_train:,} training rows)")
