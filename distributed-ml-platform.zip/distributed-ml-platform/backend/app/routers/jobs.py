import numpy as np
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import get_db
from ..ml.model import NeuralNet
from ..models import Checkpoint, Dataset, EpochMetric, Job, Task, User
from ..schemas import JobCreate, JobDetail, JobOut, MetricOut, PredictRequest, TaskOut
from ..security import current_user
from ..services import catalog, coordinator

router = APIRouter(prefix="/jobs", tags=["jobs"])


def _detail(db: Session, job: Job) -> JobDetail:
    total = db.scalar(select(func.count(Task.id)).where(Task.job_id == job.id)) or 0
    done = db.scalar(
        select(func.count(Task.id)).where(Task.job_id == job.id, Task.status == "completed")
    ) or 0
    completed_epochs = db.scalar(
        select(func.count(EpochMetric.id)).where(EpochMetric.job_id == job.id)
    ) or 0

    if job.status == "completed":
        progress = 100.0
    else:
        progress = round(100.0 * completed_epochs / max(job.epochs, 1), 1)

    model_name = next(
        (m["name"] for m in catalog.CATALOG
         if m["architecture"] == job.architecture and m["hidden_layers"] == (job.hidden_layers or [])),
        job.architecture,
    )

    payload = JobDetail.model_validate(job)
    payload.dataset_name = job.dataset.name if job.dataset else ""
    payload.model_name = model_name
    payload.progress = progress
    payload.completed_tasks = done
    payload.total_tasks = total
    return payload


@router.get("", response_model=list[JobDetail])
def list_jobs(
    status_filter: str | None = Query(default=None, alias="status"),
    db: Session = Depends(get_db),
    _: User = Depends(current_user),
):
    stmt = select(Job).order_by(Job.created_at.desc())
    if status_filter:
        stmt = stmt.where(Job.status == status_filter.lower())
    return [_detail(db, j) for j in db.scalars(stmt)]


@router.post("", response_model=JobDetail, status_code=status.HTTP_201_CREATED)
def create_job(payload: JobCreate, db: Session = Depends(get_db),
               user: User = Depends(current_user)):
    spec = catalog.resolve(payload.model)
    if spec is None:
        names = ", ".join(m["name"] for m in catalog.CATALOG)
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"Unknown model. Choose one of: {names}")

    dataset = (
        db.get(Dataset, payload.dataset_id)
        if payload.dataset_id
        else db.scalar(select(Dataset).order_by(Dataset.created_at.desc()).limit(1))
    )
    if dataset is None:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "No dataset available. Create one on the Datasets endpoint first.",
        )

    job = Job(
        name=payload.name or f"{spec['name']} on {dataset.name}",
        dataset_id=dataset.id,
        owner_id=user.id,
        architecture=spec["architecture"],
        hidden_layers=spec["hidden_layers"],
        epochs=payload.epochs,
        batch_size=payload.batch_size,
        learning_rate=payload.learning_rate or spec["learning_rate"],
        momentum=payload.momentum,
        l2=payload.l2,
        world_size=payload.world_size,
        local_steps=payload.local_steps,
        status="queued",
    )
    db.add(job)
    db.commit()
    db.refresh(job)

    coordinator.log(db, f"Job {job.id} queued — {spec['name']}, {job.world_size} workers, "
                        f"{job.epochs} epochs", "info", job.id)
    if payload.autostart:
        coordinator.start_job(db, job)
        db.refresh(job)
    return _detail(db, job)


@router.get("/{job_id}", response_model=JobDetail)
def get_job(job_id: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    job = db.get(Job, job_id)
    if job is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Job not found.")
    return _detail(db, job)


@router.post("/{job_id}/start", response_model=JobDetail)
def start_job(job_id: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    job = db.get(Job, job_id)
    if job is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Job not found.")
    if job.status == "running":
        raise HTTPException(status.HTTP_409_CONFLICT, "This job is already running.")
    if job.status == "completed":
        raise HTTPException(status.HTTP_409_CONFLICT, "This job has already finished.")
    coordinator.start_job(db, job)
    return _detail(db, job)


@router.post("/{job_id}/cancel", response_model=JobDetail)
def cancel_job(job_id: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    job = db.get(Job, job_id)
    if job is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Job not found.")
    if job.status in {"completed", "cancelled"}:
        raise HTTPException(status.HTTP_409_CONFLICT, f"This job is already {job.status}.")
    coordinator.cancel_job(db, job)
    return _detail(db, job)


@router.delete("/{job_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_job(job_id: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    job = db.get(Job, job_id)
    if job is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Job not found.")
    if job.status == "running":
        raise HTTPException(status.HTTP_409_CONFLICT, "Cancel the job before deleting it.")
    db.query(Checkpoint).filter(Checkpoint.job_id == job_id).delete()
    db.delete(job)
    db.commit()


@router.get("/{job_id}/metrics", response_model=list[MetricOut])
def job_metrics(job_id: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    return list(
        db.scalars(
            select(EpochMetric).where(EpochMetric.job_id == job_id).order_by(EpochMetric.epoch)
        )
    )


@router.get("/{job_id}/tasks", response_model=list[TaskOut])
def job_tasks(
    job_id: int,
    epoch: int | None = None,
    db: Session = Depends(get_db),
    _: User = Depends(current_user),
):
    stmt = select(Task).where(Task.job_id == job_id)
    if epoch is not None:
        stmt = stmt.where(Task.epoch == epoch)
    return list(db.scalars(stmt.order_by(Task.epoch.desc(), Task.shard_index).limit(500)))


@router.get("/{job_id}/checkpoints")
def job_checkpoints(job_id: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    rows = db.scalars(
        select(Checkpoint).where(Checkpoint.job_id == job_id).order_by(Checkpoint.epoch)
    )
    return [
        {"epoch": c.epoch, "val_accuracy": c.val_accuracy, "is_best": c.is_best,
         "created_at": c.created_at, "path": c.path}
        for c in rows
    ]


@router.post("/{job_id}/predict")
def predict(job_id: int, payload: PredictRequest, db: Session = Depends(get_db),
            _: User = Depends(current_user)):
    """Run the trained global model on new rows — proof the weights are real."""
    job = db.get(Job, job_id)
    if job is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Job not found.")

    weights_path = coordinator.run_dir(job.id) / "weights.npy"
    if not weights_path.exists():
        raise HTTPException(status.HTTP_409_CONFLICT, "This job has not trained yet.")

    X = np.asarray(payload.instances, dtype=np.float64)
    if X.ndim != 2 or X.shape[1] != job.dataset.n_features:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"Each instance needs exactly {job.dataset.n_features} features.",
        )

    net = NeuralNet(coordinator.layer_sizes_for(job))
    net.set_flat(np.load(weights_path))
    labels, probs = net.predict(X)
    return {
        "predictions": labels.tolist(),
        "probabilities": np.round(probs, 5).tolist(),
        "epoch": job.current_epoch,
    }
