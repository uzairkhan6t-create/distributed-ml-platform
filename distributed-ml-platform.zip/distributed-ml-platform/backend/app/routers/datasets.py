from fastapi import APIRouter, Depends, File, Form, HTTPException, Response, UploadFile, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..ml import data as data_utils
from ..models import Dataset, Job, User
from ..schemas import DatasetOut, SyntheticDatasetCreate
from ..security import current_user, require_cluster_token
from ..services.coordinator import log

router = APIRouter(prefix="/datasets", tags=["datasets"])


@router.get("", response_model=list[DatasetOut])
def list_datasets(db: Session = Depends(get_db), _: User = Depends(current_user)):
    return list(db.scalars(select(Dataset).order_by(Dataset.created_at.desc())))


@router.post("/synthetic", response_model=DatasetOut, status_code=status.HTTP_201_CREATED)
def create_synthetic(
    payload: SyntheticDatasetCreate,
    db: Session = Depends(get_db),
    _: User = Depends(current_user),
):
    if db.scalar(select(Dataset).where(Dataset.name == payload.name)):
        raise HTTPException(status.HTTP_409_CONFLICT, "A dataset with that name already exists.")

    ds = Dataset(
        name=payload.name,
        description=payload.description,
        source="synthetic",
        n_features=payload.n_features,
        n_classes=payload.n_classes,
        val_split=payload.val_split,
    )
    db.add(ds)
    db.commit()
    db.refresh(ds)

    X, y = data_utils.make_synthetic(
        payload.n_samples, payload.n_features, payload.n_classes,
        payload.class_sep, payload.noise, payload.seed,
    )
    n_train, _n_val, size = data_utils.persist(ds.id, X, y, payload.val_split, payload.seed)
    ds.n_samples = n_train
    ds.size_bytes = size
    db.commit()
    db.refresh(ds)

    log(db, f"Dataset '{ds.name}' generated — {n_train:,} training rows, "
            f"{ds.n_features} features", "success", source="datasets")
    return ds


@router.post("/upload", response_model=DatasetOut, status_code=status.HTTP_201_CREATED)
async def upload_csv(
    file: UploadFile = File(...),
    name: str = Form(...),
    description: str = Form(""),
    label_column: str = Form(""),
    val_split: float = Form(0.2),
    db: Session = Depends(get_db),
    _: User = Depends(current_user),
):
    """Upload a CSV. The last column is the label unless you name one."""
    if db.scalar(select(Dataset).where(Dataset.name == name)):
        raise HTTPException(status.HTTP_409_CONFLICT, "A dataset with that name already exists.")

    raw = await file.read()
    try:
        X, y, classes = data_utils.parse_csv(raw, label_column or None)
    except ValueError as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc))

    ds = Dataset(
        name=name,
        description=description or f"Uploaded from {file.filename}",
        source="csv",
        n_features=int(X.shape[1]),
        n_classes=len(classes),
        val_split=val_split,
    )
    db.add(ds)
    db.commit()
    db.refresh(ds)

    n_train, _n_val, size = data_utils.persist(ds.id, X, y, val_split)
    ds.n_samples = n_train
    ds.size_bytes = size
    db.commit()
    db.refresh(ds)

    log(db, f"Dataset '{ds.name}' uploaded — {n_train:,} rows, {len(classes)} classes",
        "success", source="datasets")
    return ds


@router.get("/{dataset_id}", response_model=DatasetOut)
def get_dataset(dataset_id: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    ds = db.get(Dataset, dataset_id)
    if ds is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Dataset not found.")
    return ds


@router.get("/{dataset_id}/shard/{world_size}/{shard_index}",
            dependencies=[Depends(require_cluster_token)])
def download_shard(dataset_id: int, world_size: int, shard_index: int,
                   db: Session = Depends(get_db)):
    """Workers pull only their slice — this is what lets nodes live on other machines."""
    ds = db.get(Dataset, dataset_id)
    if ds is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Dataset not found.")
    if not 0 <= shard_index < world_size:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Shard index is outside the world size.")

    payload = data_utils.shard_bytes(dataset_id, world_size, shard_index)
    return Response(
        content=payload,
        media_type="application/octet-stream",
        headers={"Content-Disposition": f'attachment; filename="shard_{shard_index}.npz"'},
    )


@router.delete("/{dataset_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_dataset(dataset_id: int, db: Session = Depends(get_db),
                   _: User = Depends(current_user)):
    ds = db.get(Dataset, dataset_id)
    if ds is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Dataset not found.")
    if db.scalar(select(Job).where(Job.dataset_id == dataset_id)):
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            "Training jobs still reference this dataset. Delete those jobs first.",
        )
    db.delete(ds)
    db.commit()
