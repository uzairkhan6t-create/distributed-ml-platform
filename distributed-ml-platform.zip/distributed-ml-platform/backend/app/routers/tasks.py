"""The worker-facing half of the API. Agents authenticate with the cluster token."""

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import Node, Task
from ..schemas import TaskFailure, TaskResult
from ..security import require_cluster_token
from ..services import coordinator

router = APIRouter(prefix="/tasks", tags=["worker protocol"],
                   dependencies=[Depends(require_cluster_token)])


@router.get("/next")
def next_task(node_id: int = Query(...), db: Session = Depends(get_db)):
    """Long-poll free: returns 204 when there is nothing to do."""
    node = db.get(Node, node_id)
    if node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Unknown node. Register again.")
    if node.status == "draining":
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    task = coordinator.claim_task(db, node)
    if task is None:
        return Response(status_code=status.HTTP_204_NO_CONTENT)
    return coordinator.task_payload(db, task)


@router.post("/{task_id}/result")
def submit_result(task_id: int, payload: TaskResult, db: Session = Depends(get_db)):
    task = db.get(Task, task_id)
    if task is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Task not found.")
    if task.status == "completed":
        return {"status": "duplicate", "task_id": task_id}
    return coordinator.submit_result(
        db, task, payload.gradients, payload.loss, payload.accuracy,
        payload.samples, payload.duration_ms,
    )


@router.post("/{task_id}/fail")
def report_failure(task_id: int, payload: TaskFailure, db: Session = Depends(get_db)):
    task = db.get(Task, task_id)
    if task is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Task not found.")
    coordinator.fail_task(db, task, payload.error)
    return {"status": task.status, "attempts": task.attempts}
