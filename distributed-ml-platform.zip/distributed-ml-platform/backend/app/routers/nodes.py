from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import Node, User, utcnow
from ..schemas import Heartbeat, NodeOut, NodeRegister
from ..security import current_user, require_cluster_token
from ..services.coordinator import log
from ..services.events import hub

router = APIRouter(prefix="/nodes", tags=["nodes"])


@router.post("/register", response_model=NodeOut, dependencies=[Depends(require_cluster_token)])
def register_node(payload: NodeRegister, request: Request, db: Session = Depends(get_db)):
    """A worker agent joins the cluster. Re-registering the same name reclaims the slot."""
    node = db.scalar(select(Node).where(Node.name == payload.name))
    created = node is None
    if created:
        node = Node(name=payload.name)
        db.add(node)

    node.hostname = payload.hostname
    node.ip_address = request.client.host if request.client else ""
    node.device = payload.device
    node.cpu_cores = payload.cpu_cores
    node.memory_gb = payload.memory_gb
    node.capabilities = payload.capabilities or {}
    node.status = "idle"
    node.last_heartbeat = utcnow()
    db.commit()
    db.refresh(node)

    log(db, f"{node.name} joined the cluster ({node.device}, {node.cpu_cores} cores)",
        "success", source="cluster")
    hub.publish("cluster", "node_registered", {"id": node.id, "name": node.name,
                                               "device": node.device})
    return node


@router.post("/{node_id}/heartbeat", response_model=NodeOut,
             dependencies=[Depends(require_cluster_token)])
def heartbeat(node_id: int, payload: Heartbeat, db: Session = Depends(get_db)):
    node = db.get(Node, node_id)
    if node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Unknown node. Register again.")

    node.last_heartbeat = utcnow()
    caps = dict(node.capabilities or {})
    caps.update(
        cpu_percent=round(payload.cpu_percent, 1),
        gpu_percent=round(payload.gpu_percent, 1),
        memory_percent=round(payload.memory_percent, 1),
    )
    node.capabilities = caps
    if node.status == "offline":
        node.status = "idle"
    if payload.status in {"idle", "busy", "draining"}:
        node.status = payload.status
    db.commit()
    db.refresh(node)

    hub.publish("cluster", "heartbeat", {"id": node.id, "name": node.name,
                                         "status": node.status, **caps})
    return node


@router.get("", response_model=list[NodeOut])
def list_nodes(db: Session = Depends(get_db), _: User = Depends(current_user)):
    return list(db.scalars(select(Node).order_by(Node.name)))


@router.get("/{node_id}", response_model=NodeOut)
def get_node(node_id: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    node = db.get(Node, node_id)
    if node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Node not found.")
    return node


@router.post("/{node_id}/drain", response_model=NodeOut)
def drain_node(node_id: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    """Stop giving this node new work. It finishes what it holds, then goes quiet."""
    node = db.get(Node, node_id)
    if node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Node not found.")
    node.status = "draining"
    db.commit()
    log(db, f"{node.name} was set to draining", "warning", source="cluster")
    hub.publish("cluster", "nodes_changed", {"id": node.id, "status": node.status})
    return node


@router.post("/{node_id}/activate", response_model=NodeOut)
def activate_node(node_id: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    node = db.get(Node, node_id)
    if node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Node not found.")
    node.status = "idle"
    node.last_heartbeat = utcnow()
    db.commit()
    log(db, f"{node.name} was returned to the pool", "success", source="cluster")
    hub.publish("cluster", "nodes_changed", {"id": node.id, "status": node.status})
    return node


@router.delete("/{node_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_node(node_id: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    node = db.get(Node, node_id)
    if node is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Node not found.")
    db.delete(node)
    db.commit()
