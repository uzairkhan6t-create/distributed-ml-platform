import time

from fastapi import APIRouter, Depends, Query, WebSocket, WebSocketDisconnect
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import Dataset, EpochMetric, Job, LogEntry, Node, Task, User
from ..schemas import ClusterSummary, LogOut
from ..security import current_user
from ..services import catalog
from ..services.events import hub

router = APIRouter(tags=["cluster"])
BOOT_TIME = time.time()


@router.get("/cluster/summary", response_model=ClusterSummary)
def cluster_summary(db: Session = Depends(get_db), _: User = Depends(current_user)):
    nodes = list(db.scalars(select(Node)))
    online = [n for n in nodes if n.status in {"idle", "busy", "draining"}]

    def avg(key: str) -> float:
        vals = [float((n.capabilities or {}).get(key, 0.0)) for n in online]
        return round(sum(vals) / len(vals), 1) if vals else 0.0

    recent = list(
        db.scalars(select(EpochMetric).order_by(EpochMetric.created_at.desc()).limit(10))
    )
    throughput = round(sum(m.throughput for m in recent) / len(recent), 1) if recent else 0.0

    return ClusterSummary(
        nodes_total=len(nodes),
        nodes_online=len(online),
        nodes_busy=sum(1 for n in nodes if n.status == "busy"),
        jobs_total=db.scalar(select(func.count(Job.id))) or 0,
        jobs_running=db.scalar(select(func.count(Job.id)).where(Job.status == "running")) or 0,
        jobs_completed=db.scalar(select(func.count(Job.id)).where(Job.status == "completed")) or 0,
        datasets=db.scalar(select(func.count(Dataset.id))) or 0,
        samples_processed=sum(n.samples_processed for n in nodes),
        tasks_completed=db.scalar(
            select(func.count(Task.id)).where(Task.status == "completed")
        ) or 0,
        avg_cpu=avg("cpu_percent"),
        avg_gpu=avg("gpu_percent"),
        avg_memory=avg("memory_percent"),
        throughput=throughput,
        uptime_seconds=round(time.time() - BOOT_TIME, 1),
    )


@router.get("/models")
def list_models(_: User = Depends(current_user)):
    """Architectures the platform can train."""
    return catalog.CATALOG


@router.get("/logs", response_model=list[LogOut])
def list_logs(
    job_id: int | None = None,
    level: str | None = None,
    search: str | None = None,
    limit: int = Query(default=200, le=1000),
    db: Session = Depends(get_db),
    _: User = Depends(current_user),
):
    stmt = select(LogEntry).order_by(LogEntry.created_at.desc()).limit(limit)
    if job_id is not None:
        stmt = stmt.where(LogEntry.job_id == job_id)
    if level:
        stmt = stmt.where(LogEntry.level == level)
    if search:
        stmt = stmt.where(LogEntry.message.ilike(f"%{search}%"))
    return list(db.scalars(stmt))


# --------------------------------------------------------------------------
# live stream
# --------------------------------------------------------------------------
ws_router = APIRouter(tags=["realtime"])


@ws_router.websocket("/ws/cluster")
async def cluster_stream(ws: WebSocket):
    await hub.connect("cluster", ws)
    try:
        while True:
            await ws.receive_text()      # keeps the socket open; pings are ignored
    except WebSocketDisconnect:
        await hub.disconnect("cluster", ws)
    except Exception:
        await hub.disconnect("cluster", ws)


@ws_router.websocket("/ws/jobs/{job_id}")
async def job_stream(ws: WebSocket, job_id: int):
    channel = f"job:{job_id}"
    await hub.connect(channel, ws)
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        await hub.disconnect(channel, ws)
    except Exception:
        await hub.disconnect(channel, ws)
