"""Request and response models for the public API."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# --- auth -----------------------------------------------------------------
class RegisterRequest(BaseModel):
    email: str
    password: str = Field(min_length=6)
    full_name: str = ""


class LoginRequest(BaseModel):
    email: str
    password: str


class UserOut(ORMModel):
    id: int
    email: str
    full_name: str
    role: str


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# --- nodes ----------------------------------------------------------------
class NodeRegister(BaseModel):
    name: str
    hostname: str = ""
    device: str = "cpu"
    cpu_cores: int = 1
    memory_gb: float = 1.0
    capabilities: dict = Field(default_factory=dict)


class Heartbeat(BaseModel):
    cpu_percent: float = 0.0
    gpu_percent: float = 0.0
    memory_percent: float = 0.0
    status: str | None = None


class NodeOut(ORMModel):
    id: int
    name: str
    hostname: str
    ip_address: str
    device: str
    cpu_cores: int
    memory_gb: float
    status: str
    capabilities: dict
    tasks_completed: int
    tasks_failed: int
    samples_processed: int
    last_heartbeat: datetime
    registered_at: datetime


# --- datasets -------------------------------------------------------------
class SyntheticDatasetCreate(BaseModel):
    name: str
    description: str = ""
    n_samples: int = Field(default=20000, ge=100, le=2_000_000)
    n_features: int = Field(default=32, ge=2, le=4096)
    n_classes: int = Field(default=4, ge=2, le=100)
    class_sep: float = 2.0
    noise: float = 1.0
    val_split: float = Field(default=0.2, ge=0.0, lt=0.9)
    seed: int = 7


class DatasetOut(ORMModel):
    id: int
    name: str
    description: str
    source: str
    n_samples: int
    n_features: int
    n_classes: int
    val_split: float
    size_bytes: int
    created_at: datetime


# --- jobs -----------------------------------------------------------------
class JobCreate(BaseModel):
    name: str | None = None
    model: str = "Distributed Transformer"     # catalogue name or key
    dataset_id: int | None = None
    world_size: int = Field(default=4, ge=1, le=64)
    epochs: int = Field(default=20, ge=1, le=500)
    batch_size: int = Field(default=512, ge=1, le=8192)
    learning_rate: float | None = None
    momentum: float = 0.9
    l2: float = 1e-4
    local_steps: int = Field(default=20, ge=1, le=256)
    autostart: bool = True


class JobOut(ORMModel):
    id: int
    name: str
    dataset_id: int
    architecture: str
    hidden_layers: list
    epochs: int
    batch_size: int
    learning_rate: float
    momentum: float
    l2: float
    world_size: int
    local_steps: int
    status: str
    current_epoch: int
    best_val_accuracy: float
    last_train_loss: float
    last_val_loss: float
    param_count: int
    error: str
    created_at: datetime
    started_at: datetime | None
    finished_at: datetime | None


class JobDetail(JobOut):
    dataset_name: str = ""
    model_name: str = ""
    progress: float = 0.0
    completed_tasks: int = 0
    total_tasks: int = 0


class MetricOut(ORMModel):
    epoch: int
    train_loss: float
    train_accuracy: float
    val_loss: float
    val_accuracy: float
    grad_norm: float
    samples: int
    wall_time_s: float
    throughput: float
    workers: int


class TaskOut(ORMModel):
    id: int
    job_id: int
    node_id: int | None
    epoch: int
    shard_index: int
    status: str
    attempts: int
    loss: float
    accuracy: float
    samples: int
    duration_ms: float
    error: str


# --- worker protocol ------------------------------------------------------
class TaskResult(BaseModel):
    gradients: str            # base64 float32
    loss: float
    accuracy: float
    samples: int
    duration_ms: float


class TaskFailure(BaseModel):
    error: str


class PredictRequest(BaseModel):
    instances: list[list[float]]


# --- misc -----------------------------------------------------------------
class LogOut(ORMModel):
    id: int
    job_id: int | None
    level: str
    source: str
    message: str
    created_at: datetime


class ClusterSummary(BaseModel):
    nodes_total: int
    nodes_online: int
    nodes_busy: int
    jobs_total: int
    jobs_running: int
    jobs_completed: int
    datasets: int
    samples_processed: int
    tasks_completed: int
    avg_cpu: float
    avg_gpu: float
    avg_memory: float
    throughput: float
    uptime_seconds: float
