"""Distributed ML Platform — API entrypoint.

Run with:  uvicorn backend.app.main:app --reload --port 8000
"""

from __future__ import annotations

import asyncio
import threading
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import text as sa_text

from .config import API_PREFIX, APP_NAME, APP_VERSION, REAPER_INTERVAL_S
from .db import SessionLocal, init_db
from .routers import auth, cluster, datasets, jobs, nodes, tasks
from .services import coordinator
from .services.events import hub

_stop = threading.Event()


def _reaper_loop() -> None:
    """Background health check: offline nodes, timed-out tasks."""
    while not _stop.is_set():
        try:
            db = SessionLocal()
            try:
                coordinator.reap(db)
            finally:
                db.close()
        except Exception as exc:  # never kill the thread
            print(f"[reaper] {exc}")
        _stop.wait(REAPER_INTERVAL_S)


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    hub.bind_loop(asyncio.get_running_loop())

    from .seed import ensure_seed
    db = SessionLocal()
    try:
        ensure_seed(db)
    finally:
        db.close()

    thread = threading.Thread(target=_reaper_loop, name="reaper", daemon=True)
    thread.start()
    print(f"[startup] {APP_NAME} {APP_VERSION} ready on {API_PREFIX}")
    yield
    _stop.set()


app = FastAPI(
    title=APP_NAME,
    version=APP_VERSION,
    description=(
        "Coordinator API for a distributed training cluster: worker registration, "
        "dataset sharding, synchronous data-parallel SGD, and live telemetry."
    ),
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

for r in (auth.router, nodes.router, datasets.router, jobs.router, tasks.router, cluster.router):
    app.include_router(r, prefix=API_PREFIX)
app.include_router(cluster.ws_router)


@app.get("/")
def root():
    return {
        "name": APP_NAME,
        "version": APP_VERSION,
        "docs": "/docs",
        "api": API_PREFIX,
        "realtime": ["/ws/cluster", "/ws/jobs/{job_id}"],
    }


@app.get("/health")
def health():
    db = SessionLocal()
    try:
        db.execute(sa_text("SELECT 1"))
        ok = True
    except Exception:
        ok = False
    finally:
        db.close()
    return JSONResponse({"status": "ok" if ok else "degraded", "time": time.time()})
