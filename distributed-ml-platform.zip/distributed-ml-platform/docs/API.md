# API Reference

Base URL: `http://127.0.0.1:8000`
All REST endpoints live under `/api/v1`. Interactive docs are at `/docs`.

There are two kinds of caller and two kinds of credential:

| Caller | Credential | Header |
| --- | --- | --- |
| Dashboard / human | JWT from `/auth/login` | `Authorization: Bearer <token>` |
| Worker agent | Shared cluster secret | `X-Cluster-Token: <token>` |

Agents never get a user account, and users never claim tasks. Keeping the two
apart means a compromised worker cannot read the job list or delete data.

---

## Authentication

### `POST /api/v1/auth/register`

```json
{ "email": "you@example.com", "password": "secret123", "full_name": "Your Name" }
```

The first account created becomes an admin. Returns a token and the user record.

### `POST /api/v1/auth/login`

```json
{ "email": "admin@dmlp.local", "password": "admin12345" }
```

```json
{
  "access_token": "eyJhbGciOi...",
  "token_type": "bearer",
  "user": { "id": 1, "email": "admin@dmlp.local", "role": "admin" }
}
```

### `GET /api/v1/auth/me`

Returns the signed-in user. Useful for checking a token is still valid.

---

## Nodes

### `POST /api/v1/nodes/register` — cluster token

```json
{
  "name": "Worker-01",
  "hostname": "gpu-box-3",
  "device": "cpu",
  "cpu_cores": 8,
  "memory_gb": 16.0,
  "capabilities": { "python": "3.12.3" }
}
```

Re-registering the same name reclaims the existing slot, so an agent that restarts
keeps its history instead of creating a duplicate.

### `POST /api/v1/nodes/{id}/heartbeat` — cluster token

```json
{ "cpu_percent": 62.0, "gpu_percent": 78.4, "memory_percent": 41.0 }
```

Agents send this every 8 seconds. A node silent for longer than
`DMLP_HEARTBEAT_TIMEOUT` is marked offline and its work is requeued.

### `GET /api/v1/nodes` — JWT

Lists every node with live utilisation and lifetime counters.

### `POST /api/v1/nodes/{id}/drain` — JWT

Stops giving the node new tasks. It finishes what it holds first.

### `POST /api/v1/nodes/{id}/activate` — JWT

Returns a drained or offline node to the pool.

### `DELETE /api/v1/nodes/{id}` — JWT

Removes the node record.

---

## Datasets

### `POST /api/v1/datasets/synthetic` — JWT

```json
{
  "name": "Benchmark A",
  "n_samples": 50000,
  "n_features": 32,
  "n_classes": 5,
  "class_sep": 1.5,
  "noise": 1.0,
  "val_split": 0.2
}
```

Generates Gaussian clusters passed through a random linear mixing, then normalises
and splits into train and validation.

### `POST /api/v1/datasets/upload` — JWT, multipart

Fields: `file`, `name`, `description`, `label_column`, `val_split`.
The last column is treated as the label unless `label_column` names another.
Non-numeric labels are mapped to class indices automatically.

### `GET /api/v1/datasets` — JWT

### `GET /api/v1/datasets/{id}` — JWT

### `GET /api/v1/datasets/{id}/shard/{world_size}/{shard_index}` — cluster token

Returns one contiguous slice as a compressed `.npz` body. This is how a worker on
another machine gets its data without any shared storage.

### `DELETE /api/v1/datasets/{id}` — JWT

Refuses while training jobs still reference the dataset.

---

## Jobs

### `POST /api/v1/jobs` — JWT

```json
{
  "model": "CNN Image Model",
  "dataset_id": 1,
  "world_size": 4,
  "epochs": 20,
  "batch_size": 512,
  "local_steps": 20,
  "learning_rate": 0.06,
  "momentum": 0.9,
  "l2": 0.0001,
  "autostart": true
}
```

Only `model` is required — everything else falls back to the catalogue defaults and
the most recent dataset. `world_size` is the number of shards, so it is also the
number of workers that can train in parallel.

Response includes `progress`, `param_count`, `dataset_name` and `model_name` on top
of the stored fields.

### `GET /api/v1/jobs` — JWT

Optional `?status=running`.

### `GET /api/v1/jobs/{id}` — JWT

### `POST /api/v1/jobs/{id}/start` — JWT

Starts a queued job, or resumes one that was cancelled.

### `POST /api/v1/jobs/{id}/cancel` — JWT

Stops the job and releases its workers.

### `DELETE /api/v1/jobs/{id}` — JWT

Refuses while the job is running — cancel it first.

### `GET /api/v1/jobs/{id}/metrics` — JWT

One row per completed round:

```json
[
  {
    "epoch": 1,
    "train_loss": 2.833,
    "train_accuracy": 0.1021,
    "val_loss": 2.7104,
    "val_accuracy": 0.1263,
    "grad_norm": 0.412,
    "samples": 30720,
    "wall_time_s": 3.42,
    "throughput": 8967.0,
    "workers": 4
  }
]
```

### `GET /api/v1/jobs/{id}/tasks` — JWT

Per-shard breakdown. Optional `?epoch=5`. Shows which node ran which shard and how
long each took, which is where you can see stragglers.

### `GET /api/v1/jobs/{id}/checkpoints` — JWT

### `POST /api/v1/jobs/{id}/predict` — JWT

```json
{ "instances": [[0.12, -1.4, ...]] }
```

```json
{ "predictions": [4], "probabilities": [[0.02, 0.01, ...]], "epoch": 20 }
```

Each instance needs exactly as many values as the dataset has features.

---

## Worker protocol

All three require `X-Cluster-Token`.

### `GET /api/v1/tasks/next?node_id=1`

Returns `204 No Content` when there is no work. Otherwise:

```json
{
  "task_id": 41,
  "job_id": 2,
  "epoch": 5,
  "shard_index": 2,
  "world_size": 4,
  "dataset_id": 1,
  "shard_samples": 30000,
  "layer_sizes": [64, 128, 64, 8],
  "batch_size": 512,
  "local_steps": 20,
  "l2": 0.0001,
  "weights": "<base64 float32>"
}
```

### `POST /api/v1/tasks/{id}/result`

```json
{
  "gradients": "<base64 float32>",
  "loss": 1.2939,
  "accuracy": 0.6076,
  "samples": 10240,
  "duration_ms": 1840.2
}
```

Submitting the final shard of a round triggers aggregation, evaluation and the next
round, all inside the same request.

### `POST /api/v1/tasks/{id}/fail`

```json
{ "error": "shard download timed out" }
```

Requeues the task, or fails the job after three attempts.

---

## Cluster and observability

### `GET /api/v1/cluster/summary` — JWT

Node counts, job counts, average CPU/GPU/memory across online nodes, total samples
processed and recent throughput.

### `GET /api/v1/models` — JWT

The architectures the platform can train, with hidden layer sizes and recommended
settings.

### `GET /api/v1/logs` — JWT

Filters: `job_id`, `level`, `search`, `limit` (max 1000).

### `GET /health`

No authentication. Returns `ok` or `degraded` — suitable for a load balancer probe.

---

## WebSockets

- `ws://127.0.0.1:8000/ws/cluster` — everything
- `ws://127.0.0.1:8000/ws/jobs/{job_id}` — one job only

Frames look like:

```json
{
  "event": "epoch_completed",
  "channel": "job:2",
  "ts": "2026-09-02T08:12:44.102Z",
  "data": { "job_id": 2, "epoch": 5, "val_accuracy": 0.743, "progress": 25.0 }
}
```

Event names: `log`, `node_registered`, `nodes_changed`, `heartbeat`,
`round_opened`, `task_assigned`, `task_completed`, `epoch_completed`,
`job_started`, `job_progress`, `job_completed`, `job_cancelled`, `job_failed`.

Send any text frame periodically to keep the socket alive; the server ignores the
contents.

---

## Errors

Standard HTTP codes with a readable `detail` string:

| Code | Meaning |
| --- | --- |
| 400 | The request was malformed — the message says what to fix |
| 401 | Missing, expired or invalid JWT |
| 403 | Wrong cluster token |
| 404 | No such job, node or dataset |
| 409 | The action conflicts with current state (deleting a running job, duplicate name) |
