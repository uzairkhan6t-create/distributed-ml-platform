#!/usr/bin/env bash
# Start N worker agents in the background. Usage: ./scripts/start_workers.sh 4
set -e
COUNT="${1:-4}"
SERVER="${2:-http://127.0.0.1:8000}"
cd "$(dirname "$0")/.."
mkdir -p logs
for i in $(seq 1 "$COUNT"); do
  NAME=$(printf "Worker-%02d" "$i")
  python worker/agent.py --name "$NAME" --server "$SERVER" > "logs/$NAME.log" 2>&1 &
  echo "started $NAME (pid $!) -> logs/$NAME.log"
done
echo
echo "Stop them all with: pkill -f worker/agent.py"
