@echo off
REM Start N worker agents, each in its own window. Usage: scripts\start_workers.bat 4
setlocal
set COUNT=%1
if "%COUNT%"=="" set COUNT=4
set SERVER=%2
if "%SERVER%"=="" set SERVER=http://127.0.0.1:8000

cd /d "%~dp0.."
for /L %%i in (1,1,%COUNT%) do (
  start "Worker-%%i" cmd /k python worker\agent.py --name Worker-0%%i --server %SERVER%
)
echo Started %COUNT% workers. Close each window to stop them.
